import os,sys,json,subprocess,concurrent.futures,datetime,time,re,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CAT={
'OpenAI':['openai/openai-agents-python','openai/openai-agents-js','openai/openai-cookbook'],
'Anthropic':['anthropics/claude-agent-sdk-python','anthropics/anthropic-sdk-python','anthropics/skills'],
'Model Context Protocol':['modelcontextprotocol/python-sdk','modelcontextprotocol/typescript-sdk','modelcontextprotocol/go-sdk'],
'Google DeepMind / Gemini':['google-gemini/gemini-cli','google-deepmind/chex','google-deepmind/mujoco'],
'xAI':['xai-org/xai-sdk-python','xai-org/xai-cookbook','xai-org/plugin-marketplace'],
'Cognition / Devin':['CognitionAI/terraform-provider-devin','CognitionAI/metabase-mcp-server','CognitionAI/devin-cli'],
'Cursor / Anysphere':['cursor/community-plugins','cursor/cookbook','anysphere/priompt'],
'Agentica / DeepSWE':['agentica-project/rllm','agentica-project/R2E-Gym','agentica-project/verl-pipeline'],
'Together AI':['togethercomputer/together-cookbook','togethercomputer/together-python','togethercomputer/RedPajama-Data'],
'Prime Intellect':['PrimeIntellect-ai/verifiers','PrimeIntellect-ai/prime-rl','PrimeIntellect-ai/prime'],
'Meta AI / FAIR / PyTorch':['pytorch/torchtitan','pytorch/ao','pytorch/pytorch'],
'Microsoft AI':['microsoft/autogen','microsoft/agent-framework','microsoft/markitdown'],
'Mistral':['mistralai/mistral-common','mistralai/cookbook','mistralai/client-python'],
'Hugging Face':['huggingface/peft','huggingface/transformers','huggingface/smolagents'],
'Cohere':['cohere-ai/cohere-developer-experience','cohere-ai/north-mcp-python-sdk','cohere-ai/cohere-python'],
'Ai2':['allenai/OLMo-core','allenai/open-instruct','allenai/dolma'],
'EleutherAI':['EleutherAI/lm-evaluation-harness','EleutherAI/gpt-neox','EleutherAI/sae'],
'DeepSeek':['deepseek-ai/smallpond','deepseek-ai/DeepEP','deepseek-ai/DeepGEMM'],
'Qwen':['QwenLM/Qwen-Agent','QwenLM/qwen-code','QwenLM/qwen-code-docs'],
'Unsloth':['unslothai/unsloth','unslothai/unsloth-zoo','unslothai/notebooks'],
'Sakana AI':['SakanaAI/ShinkaEvolve','SakanaAI/treequest','SakanaAI/AI-Scientist'],
'Perplexity':['perplexityai/modelcontextprotocol','perplexityai/search_evals','perplexityai/bumblebee'],
'Nous Research':['NousResearch/hermes-agent','NousResearch/hermes-example-plugins','NousResearch/tinker-atropos'],
'NVIDIA':['NVIDIA/NeMo','NVIDIA/garak','NVIDIA/TensorRT-LLM'],
'vLLM':['vllm-project/vllm','vllm-project/semantic-router','vllm-project/production-stack'],
'SGLang':['sgl-project/sglang','sgl-project/sglang-omni','sgl-project/sglang-jax'],
'OpenHands':['OpenHands/OpenHands','OpenHands/software-agent-sdk','OpenHands/extensions'],
'Goose':['block/goose','block/buzz','block/agent-task-queue'],
'Aider':['Aider-AI/aider','Aider-AI/polyglot-benchmark','Aider-AI/grep-ast'],
'Cline':['cline/cline','cline/cline-bench','cline/kanban'],
'Continue':['continuedev/continue','continuedev/checks','continuedev/amplified.dev'],
'SWE-agent':['SWE-agent/SWE-agent','SWE-agent/mini-swe-agent','SWE-agent/SWE-ReX'],
}
AVOID=['xai-org/grok-build','deepseek-ai/deepseek-harness','googleapis/python-genai','pytorch/torchtune','mistralai/mistral-inference','OpenHands/OpenHands-CLI','anthropics/claude-agent-sdk-typescript','openai/codex','mistralai/mistral-vibe','anthropics/claude-code','cursor/cursor','google/adk-python','openai/openai-python','cohere-ai/cohere-toolkit','NousResearch/atropos']
(ROOT/'catalog.json').write_text(json.dumps({'labs':CAT,'avoid':AVOID},indent=2))
def gh(args):
 for k in range(3):
  p=subprocess.run(['gh','api']+args,capture_output=True,text=True)
  if p.returncode==0:return json.loads(p.stdout)
  if 'rate limit' in p.stderr.lower():time.sleep(20*(k+1))
  else:raise RuntimeError(p.stderr[:600])
 raise RuntimeError(p.stderr[:600])
def gql(q):return gh(['graphql','-f','query='+q])['data']
AUTHOR='author{__typename login url ... on User{company bio organizations(first:10){nodes{login}}}} authorAssociation'
PR='number title url createdAt updatedAt mergedAt '+AUTHOR
ISS='number title url body createdAt updatedAt assignees(first:10){nodes{login}} labels(first:15){nodes{name}} timelineItems(last:30,itemTypes:[CROSS_REFERENCED_EVENT,CONNECTED_EVENT]){nodes{__typename ... on CrossReferencedEvent{source{__typename ... on PullRequest{number url state title}}} ... on ConnectedEvent{subject{__typename ... on PullRequest{number url state title}}}}} comments(last:8){nodes{author{login} body url createdAt}}'
def repo(slug):
 out=ROOT/'raw'/ (slug.replace('/','__')+'.json')
 if out.exists():return slug,'cached'
 owner,name=slug.split('/')
 q='query{repository(owner:'+json.dumps(owner)+',name:'+json.dumps(name)+'){nameWithOwner url description stargazerCount isArchived isFork pushedAt primaryLanguage{name} defaultBranchRef{name target{oid}} owner{login url} merged:pullRequests(first:100,states:MERGED,orderBy:{field:UPDATED_AT,direction:DESC}){totalCount pageInfo{hasNextPage endCursor} nodes{'+PR+'}} open:pullRequests(first:100,states:OPEN,orderBy:{field:CREATED_AT,direction:ASC}){totalCount pageInfo{hasNextPage endCursor} nodes{'+PR+'}} issues(first:40,states:OPEN,orderBy:{field:UPDATED_AT,direction:DESC}){totalCount pageInfo{hasNextPage endCursor} nodes{'+ISS+'}}}}'
 try:
  d=gql(q)['repository'];d['collectedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
  out.write_text(json.dumps(d,indent=2));return slug,'ok'
 except Exception as e:
  (ROOT/'raw'/(slug.replace('/','__')+'.error.txt')).write_text(str(e));return slug,str(e)[:100]
def policies(slug):
 p=ROOT/'raw'/(slug.replace('/','__')+'.json')
 if not p.exists():return slug,'missing'
 d=json.loads(p.read_text());base=ROOT/'policies'/slug.replace('/','__');base.mkdir(exist_ok=True)
 if (base/'index.json').exists():return slug,'cached'
 try:
  sha=d['defaultBranchRef']['target']['oid'];tree=gh([f'repos/{slug}/git/trees/{sha}?recursive=1'])
  paths=[x['path'] for x in tree.get('tree',[]) if x['type']=='blob' and (re.search(r'(^|/)(contributing[^/]*|pull_request_template[^/]*|cla(?:\.md|\.txt|\.rst)?|dco(?:\.md|\.txt|\.rst)?|codeowners)$',x['path'],re.I) or re.search(r'^\.github/(workflows/.*\.ya?ml|PULL_REQUEST_TEMPLATE/)',x['path']) or x['path'].lower() in ['readme.md','readme.rst'])]
  index=[]
  for off in range(0,len(paths),20):
   batch=paths[off:off+20]
   needed=[x for x in batch if not (base/x.replace('/','__')).exists()]
   if needed:
    fields=' '.join('f'+str(i)+':object(expression:'+json.dumps(sha+':'+path)+'){... on Blob{text}}' for i,path in enumerate(needed))
    owner,name=slug.split('/')
    result=gql('query{repository(owner:'+json.dumps(owner)+',name:'+json.dumps(name)+'){'+fields+'}}')['repository']
    for i,path in enumerate(needed):
     blob=result.get('f'+str(i))
     if blob and blob.get('text') is not None:(base/path.replace('/','__')).write_text(blob['text'])
   for path in batch:
    fn=path.replace('/','__')
    index.append({'path':path,'file':fn,'url':f'https://github.com/{slug}/blob/{sha}/{path}'} if (base/fn).exists() else {'path':path,'error':'No text blob returned'})
  (base/'index.json').write_text(json.dumps({'sha':sha,'truncated':tree.get('truncated'),'files':index},indent=2))
  return slug,len(paths)
 except Exception as e:return slug,str(e)
def history():
 data=gh(['--method','GET','search/issues','-f','q=is:pr author:rohan-patnaik -user:rohan-patnaik is:public','-f','per_page=100'])
 (ROOT/'history-search.json').write_text(json.dumps(data,indent=2))
 def one(item):
  slug=item['repository_url'].split('repos/')[1];num=item['number'];f=ROOT/'raw'/f'history__{slug.replace("/","__")}__{num}.json'
  if f.exists():return
  p=gh([f'repos/{slug}/pulls/{num}']);p['discussion']=gh([f'repos/{slug}/issues/{num}/comments?per_page=100']);p['reviews_full']=gh([f'repos/{slug}/pulls/{num}/reviews?per_page=100']);p['review_comments']=gh([f'repos/{slug}/pulls/{num}/comments?per_page=100']);f.write_text(json.dumps(p,indent=2))
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:list(ex.map(one,data['items']))
 print('History',data['total_count'],flush=True)
if __name__=='__main__':
 mode=sys.argv[1] if len(sys.argv)>1 else 'repos'
 if mode=='history':history();sys.exit()
 targets=list(dict.fromkeys(sum(CAT.values(),[])+AVOID))
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
  for result in ex.map(policies if mode=='policies' else repo,targets):print(*result,flush=True)
