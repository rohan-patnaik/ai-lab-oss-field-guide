"""Editorial scope for the 19 September issue-resolution revision."""
from collect import CAT as ORIGINAL_CAT
import json
from pathlib import Path

EXCLUDED = {
 'openai/openai-cookbook':'Cookbook/examples',
 'anthropics/skills':'Skill/example collection',
 'xai-org/xai-cookbook':'Cookbook/examples',
 'xai-org/plugin-marketplace':'Plugin catalog',
 'cursor/community-plugins':'Plugin catalog',
 'cursor/cookbook':'Cookbook/examples',
 'togethercomputer/together-cookbook':'Cookbook/examples',
 'mistralai/cookbook':'Cookbook/examples',
 'cohere-ai/cohere-developer-experience':'Documentation/examples and synced content',
 'QwenLM/qwen-code-docs':'Documentation-only repository',
 'unslothai/notebooks':'Notebook/example collection',
 'NousResearch/hermes-example-plugins':'Example plugins',
 'OpenHands/extensions':'Public skills/plugin registry',
 'continuedev/checks':'Reusable checks/skill collection',
 'continuedev/amplified.dev':'Editorial essay/supporter site',
}
CAT={lab:[s for s in slugs if s not in EXCLUDED] for lab,slugs in ORIGINAL_CAT.items()}
# repo, number -> scope, evidence/qualification, test and next decision.
CASES={
 ('EleutherAI/lm-evaluation-harness',2614):('LOW','MGSM English/native template tags collide.','SOURCE CONFIRMED: both current templates say mgsm_cot_native; maintainer comment agrees they should differ.','Change the source template and regenerate affected task configs; assert English/native selections are distinct without loading a model.'),
 ('EleutherAI/lm-evaluation-harness',2289):('LOW','Documented None seeds conflict with int-only API annotations.','SOURCE CONFIRMED: current signature and None-handling/docstrings disagree.','Correct the declared accepted inputs; type-check a documented None call and verify seed-setting behavior is unchanged.'),
 ('EleutherAI/lm-evaluation-harness',2371):('MEDIUM','Regex extraction strips indentation needed by generated Python.','ISOLATED REPRODUCTION: current RegexFilter turns four leading spaces plus return 1 into return 1; full evaluation impact remains unverified.','Supply the end-to-end code-generation example the maintainer requested; agree on compatibility-preserving behavior before changing strip defaults.'),
 ('EleutherAI/lm-evaluation-harness',3120):('MEDIUM','--check_integrity cannot locate test root in the reported installation.','REPORTED: current helper still searches a bounded parent path; installation-specific failure not reproduced.','Recreate source and wheel installations; determine whether tests are packaged/supported before changing discovery or the error message.'),
 ('SWE-agent/SWE-ReX',241):('LOW','Modal deployment unit test unexpectedly requires external credentials.','SOURCE INSPECTED: factory test constructs ModalDeployment, whose constructor calls modal.App.lookup; reported failure not executed here.','Reproduce in a clean credential-free environment; isolate the unit factory test from Modal lookup and preserve separately marked integration coverage.'),
 ('SWE-agent/SWE-ReX',279):('MEDIUM','Bash parsing failure is obscured by a ParsingError constructor failure.','REPORTED: Python 3.11 retry did not resolve it; exact failing command/transport path still needed.','Capture the smallest failing shell input, trace exception serialization, and add a regression preserving the original parser error.'),
 ('SWE-agent/SWE-ReX',175):('MEDIUM','Invalid UTF-8 in file content aborts an agent workflow.','REPORTED: old traceback; current behavior and intended decoding contract not verified.','Use a local invalid-byte fixture; agree on strict/replacement behavior rather than assuming permissive decoding is desired.'),
 ('modelcontextprotocol/python-sdk',3545):('MEDIUM','Server rejects a Basic-authenticated OAuth request without client_id in its body.','REPORTED: concrete protocol/authentication failure; no local execution.','Test a legitimate client_secret_basic request, invalid credentials and supported alternative methods. Obtain assignment/help-wanted before a PR.'),
 ('modelcontextprotocol/python-sdk',3544):('MEDIUM','Fourteen client snapshot tests fail on Windows because _meta is a wire alias.','REPORTED: locked dependency versions and Windows commands supplied; not reproduced on Windows here.','Trace inline_snapshot/Pydantic alias ownership; run the affected suite on Windows and another OS. Fix the owning layer, not production wire semantics to appease a test.'),
 ('modelcontextprotocol/go-sdk',1263):('HIGH','Server cannot emit the required subscription-teardown cancellation notification.','REPORTED with protocol citations and a reproducer; new exported API requires proposal approval.','Prove current wire behavior, agree on teardown ownership/API, and test cancellation/completion ordering and legacy protocol compatibility.'),
 ('google-deepmind/mujoco',3596):('HIGH','Recompile preserves controls by actuator ordinal instead of control-block identity.','REPORTED with native reproduction; prior source inspection supports investigation, not a completed runtime verification.','Build current native library; test zero-, one- and multi-input actuators, remapping and no-op recompile, including sanitizers.'),
 ('google-deepmind/mujoco',3585):('HIGH','No-op recompile resets documented integration-state fields.','REPORTED with state-preservation cases; native suite not executed here.','Agree on the exact preserved-state contract; compare before/after state on the changed native build, including topology changes.'),
 ('OpenHands/software-agent-sdk',4670):('MEDIUM','Stopping a silent WebSocket leaks its worker and clears the live thread reference.','REPORTED with a deterministic local-peer reproducer; current issue readiness gate remains unsatisfied.','Reproduce with a silent local peer; test stop races, repeated start/stop and timeout cleanup. Ask triage to settle readiness before implementation.'),
 ('OpenHands/software-agent-sdk',4731):('MEDIUM','TypeScript WebSocket initialization breaks ESM bundlers.','REPORTED: source exists in the SDK snapshot; current client ownership and readiness must be confirmed.','Build a minimal supported browser and Node consumer; identify the active TypeScript repository before choosing a fix. Do not silently raise the Node minimum.'),
 ('OpenHands/software-agent-sdk',5074):('HIGH','Restart loses child-task mappings and leaves persisted children permanently running.','REPORTED with TestLLM/process-death reproduction; readiness and recovery semantics require triage.','Prefer an agreed minimal interrupted/error recovery path over inventing durable orchestration. Kill/restart a local test server; check child terminal state and parent result exactly once.'),
 ('OpenHands/software-agent-sdk',4990):('HIGH','Pause reports PAUSED while ACP tools continue modifying the workspace.','REPORTED with timed observations; pause-versus-interrupt semantics need maintainer agreement.','Use a deterministic local ACP peer; establish when PAUSED becomes truthful, then test ongoing work, cancellation, resume and state reporting.'),
 ('PrimeIntellect-ai/prime',876):('MEDIUM','User-owned environment eval push fails with a team-membership 403; APIError classes differ.','REPORTED with request/response evidence; client/backend boundary not independently reproduced.','Confirm lookup contract and error-class ownership; test user/team owners and authorization failures with a stub, followed by an allowed account integration check.'),
 ('pytorch/torchtitan',4783):('HIGH','Rotary inv_freq is uninitialized after to_empty, regressing a prior fix.','REPORTED training correctness defect; no training run performed.','Reproduce initialization on the supported backend; compare deterministic rotary values before running the required training/GPU checks.'),
 ('pytorch/ao',4904):('MEDIUM','aarch64 regression CI cannot find an ExecuTorch threadpool header.','REPORTED CI failure; source dependency/build ownership requires confirmation.','Recreate the pinned macOS/arm64 build and fix include/dependency wiring in the owning project; show the same CI target passes.'),
 ('mistralai/client-python',625):('MEDIUM','Transient network failures abort BatchClient.wait polling.','REPORTED; Speakeasy generation means editable-source route must be agreed.','Use a controlled transport failure between successful polls; bound retries/cancellation and preserve terminal errors. Work in the approved custom/generator source.'),
 ('huggingface/transformers',48887):('HIGH','Gemma audio processing reports mismatched audio features and tokens.','REPORTED with supplied audio; maintainers are investigating the model/input path.','Reproduce with the attached audio and current main, resolve xgrammar/input configuration, and coordinate with the named maintainers before coding.'),
 ('allenai/open-instruct',1899):('MEDIUM','Published model chat template differs from the recorded training template.','REPORTED artifact mismatch; the correct model-artifact/code owner is unresolved.','Compare tokenized fixtures and training configuration; obtain the intended inference template and submit to the actual owning repository.'),
 ('EleutherAI/sae',130):('MEDIUM','FVU differs between training and evaluation.','REPORTED metric discrepancy; data/normalization cause not established.','Evaluate one fixed batch with identical centering/normalization; locate the difference before altering metric definitions.'),
 ('SakanaAI/AI-Scientist',251):('MEDIUM','Unquoted writeup_file lets shell metacharacters change the chktex command.','REPORTED code defect; no exploitation or full scientist run performed.','Use harmless local path fixtures; pass arguments without shell interpolation and verify spaces/metacharacters remain literal.'),
 ('NousResearch/tinker-atropos',30):('MEDIUM','Installation fails in the reported environment.','REPORTED only; exact current package/environment support must be checked.','Create a clean environment with the reporter versions; trace the first dependency error and confirm which package owns the fix.'),
 ('NVIDIA/NeMo',16278):('HIGH','Sortformer splits one speaker when microphone distance changes.','REPORTED model behavior; no evidence yet that a small source patch is appropriate.','Obtain permitted audio and model/version settings; quantify diarization error and distinguish model limitation from implementation defect before proposing code.'),
 ('NVIDIA/TensorRT-LLM',18662):('HIGH','DSA MTP accepts no draft tokens with the v2 KV cache manager disabled.','REPORTED inference defect; GPU path not exercised.','Reproduce the exact cache-manager/model configuration, isolate correctness versus configuration, and obtain an approved issue plus DCO before code review.'),
 ('block/buzz',7737):('LOW','macOS notification banners show a generic icon instead of the sender avatar.','REPORTED product failure; desired platform capability and renderer ownership unverified.','Reproduce on supported macOS; verify OS notification limitations before a renderer/packaging patch. Lower ML relevance than the portfolio anchors.'),
 ('Aider-AI/aider',5729):('MEDIUM','ImportError in scipy _svdp prevents startup.','REPORTED installation failure; environment or dependency issue may be outside Aider.','Recreate exact Python/NumPy/SciPy versions and locate packaging responsibility. Do not submit an arbitrary dependency bump.'),
 ('Aider-AI/polyglot-benchmark',11):('HIGH','Test implementation reportedly changes measured pass@1.','REPORTED evaluation-validity concern; root cause and desired methodology unverified.','Use fixed solutions and isolated runner conditions; prove which test behavior changes correctness outcomes before altering benchmark methodology.'),
 ('cline/kanban',644):('MEDIUM','Bypass-permissions setting launches auto mode, leaving cards stalled.','REPORTED flag translation bug; local code path and version must be reproduced.','Assert the spawned arguments for each supported setting and verify resulting mode with a local safe fixture; preserve explicit user choices.'),
}

def revised_issues():
    result={s:{} for slugs in CAT.values() for s in slugs}
    for (slug,num),(level,impact,evidence,validation) in CASES.items():
        path=Path(__file__).parent/'revision'/'issue-audit'/f'{slug.replace("/","__")}__{num}.json'
        a=json.loads(path.read_text())
        if a['state']!='OPEN' or a['assignees']['nodes'] or a['linkedPRs']:continue
        item={**a,'audit':a,'impact':impact,'evidence':evidence,'validation':validation}
        result[slug].setdefault(level,[]).append(item)
    return result
