from collect import *
short=json.loads((ROOT/'shortlist.json').read_text())
portfolio={'SWE-agent/SWE-ReX':[92,75],'EleutherAI/lm-evaluation-harness':[2356,2639],'vllm-project/production-stack':[628,785],'OpenHands/software-agent-sdk':[4670,4731,4978,4973],'google-deepmind/mujoco':[3596,3585]}
targets=set((s,a['number']) for s,bs in short.items() for arr in bs.values() for a in arr)|set((s,n) for s,ns in portfolio.items() for n in ns)
OUT=ROOT/'issue-audit';OUT.mkdir(exist_ok=True)
def verify(item):
 slug,num=item;file=OUT/f'{slug.replace("/","__")}__{num}.json'
 if file.exists():return slug,num,'cached'
 own,name=slug.split('/');cursor=None;events=[];issue=None
 for page in range(15):
  q='query{repository(owner:'+json.dumps(own)+',name:'+json.dumps(name)+'){issue(number:'+str(num)+'){number title url state body assignees(first:100){nodes{login}} labels(first:40){nodes{name}} comments(last:100){totalCount nodes{author{login} body url createdAt}} timelineItems(first:100,itemTypes:[CROSS_REFERENCED_EVENT,CONNECTED_EVENT]'+(',after:'+json.dumps(cursor) if cursor else '')+'){totalCount pageInfo{hasNextPage endCursor} nodes{__typename ... on CrossReferencedEvent{source{__typename ... on PullRequest{number url state title}}} ... on ConnectedEvent{subject{__typename ... on PullRequest{number url state title}}}}}}}}'
  issue=gql(q)['repository']['issue'];tl=issue['timelineItems'];events+=tl['nodes'];cursor=tl['pageInfo']['endCursor']
  if not tl['pageInfo']['hasNextPage']:break
 issue['timelineItems']['nodes']=events;issue['checkedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();prs=[n.get('source',n.get('subject',{})) for n in events];issue['linkedPRs']=[p for p in prs if p.get('__typename')=='PullRequest']
 if item in set((s,n) for s,ns in portfolio.items() for n in ns):
  query=f'repo:{slug} is:pr "{num}" in:body';r=gql('query{search(type:ISSUE,query:'+json.dumps(query)+',first:30){issueCount nodes{... on PullRequest{number title url state body}}}}')['search'];issue['competitionSearch']=r
 file.write_text(json.dumps(issue,indent=2));return slug,num,len(issue['linkedPRs']),issue['state'],len(issue['assignees']['nodes'])
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 for x in ex.map(verify,targets):print(*x,flush=True)
