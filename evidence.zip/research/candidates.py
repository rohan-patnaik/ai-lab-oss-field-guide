from collect import *
CLAIM=re.compile(r'(?:I(?:\s+|[’\']?)(?:m|am|have|ve|will|d|would|can|want|plan|started)|working on|fix.*ready|PR.*ready|take this|take it|pick this|pick it|assign.*me|implement.*myself)',re.I)
def candidates(slug):
 d=json.loads((ROOT/'raw'/(slug.replace('/','__')+'.json')).read_text());result=[]
 for a in d.get('expandedIssues',d['issues'])['nodes']:
  if a['assignees']['nodes']:continue
  refs=[n.get('source',n.get('subject',{})) for n in a.get('timelineItems',{}).get('nodes',[])];prs=[r for r in refs if r.get('__typename')=='PullRequest']
  comments=a.get('comments',{}).get('nodes',[]);alltext=a['body']+'\n'+'\n'.join(c['body'] for c in comments)
  if prs or re.search(r'github\.com/[^\s/]+/[^\s/]+/pull/\d+',alltext):continue
  labels=[l['name'] for l in a['labels']['nodes']]
  claims=[c for c in comments if CLAIM.search(c['body']) and (c['author'] or {}).get('login') not in ['github-actions','stale']]
  if claims:continue
  if re.search(r'(?:fix|tests?|patch|implementation).{0,25}ready|(?:I have|I.ve).{0,40}(?:fix|implemented)|(?:I.d|I would).{0,25}(?:take|PR|work|fix)',a['body'],re.I):continue
  if any(re.search(r'maintainer.only|duplicate|invalid|support|question|wip',l,re.I) for l in labels):continue
  result.append(a)
 return result
if __name__=='__main__':
 slugs=sys.argv[1:] or ['openai/openai-cookbook','modelcontextprotocol/go-sdk','huggingface/peft','EleutherAI/lm-evaluation-harness','OpenHands/software-agent-sdk','NVIDIA/garak','vllm-project/production-stack']
 for s in slugs:
  print('\n##',s)
  for a in candidates(s):print(a['number'],a['title'][:140],[l['name'] for l in a['labels']['nodes']])
