"""Render the completed Markdown into a standalone, offline-readable field guide."""
import html
import json
import re
import sys
from pathlib import Path
sys.path.insert(0, '/tmp/oss-report-python')
import markdown

ROOT = Path(__file__).resolve().parent.parent
md = (ROOT/'report.md').read_text()
metrics = json.loads((ROOT/'research/metrics.json').read_text())
labs = json.loads((ROOT/'research/labs.json').read_text())
by_slug = {m['slug']:m for m in metrics}
selected = {s for lab in labs for s in lab['slugs']}

def render(source):
    text = markdown.markdown(source,extensions=['tables','fenced_code','toc'])
    text = re.sub(r'<table>(.*?)</table>',r'<div class="table-scroll" tabindex="0" role="region" aria-label="Scrollable data table"><table>\1</table></div>',text,flags=re.S)
    text = re.sub(r'<strong>(LOW|MEDIUM|HIGH)(:?)</strong>',lambda m:f'<strong class="badge {m[1].lower()}">{m[1]}</strong>{m[2]}',text)
    text = re.sub(r'<td>(LOW|MEDIUM|HIGH)</td>',lambda m:f'<td><strong class="badge {m[1].lower()}">{m[1]}</strong></td>',text)
    def label_table(match):
        table = match[0]
        labels = re.findall(r'<th>(.*?)</th>', table, re.S)
        def label_row(row):
            cells = iter(labels)
            return re.sub(r'<td>', lambda _: '<td data-label="'+html.escape(next(cells,''),quote=True)+'">', row[0])
        return re.sub(r'<tr>.*?</tr>', label_row, table, flags=re.S)
    text = re.sub(r'<table>.*?</table>', label_table, text, flags=re.S)
    return text

parts = re.split(r'^## ',md,flags=re.M)
sections = {p.split('\n',1)[0]:p.split('\n',1)[1] for p in parts[1:]}

def section(title, target, klass=''):
    return f'<section class="report-section {klass}" id="{target}"><div class="section-heading"><span class="eyebrow">FIELD NOTES</span><h2>{html.escape(title)}</h2></div>{render(sections[title])}</section>'

def bar(m):
    share = m['share'] or 0
    label = f"{m['share']}% · {m['external']}/{m['human']}" if m['human'] else 'No human sample'
    return f'<div class="bar-row"><a href="{m["url"]}">{html.escape(m["slug"])}</a><div class="bar-track"><span style="width:{share}%"></span></div><span class="bar-value">{label}</span></div>'

top = ['EleutherAI/lm-evaluation-harness','vllm-project/production-stack','google-deepmind/mujoco','openai/openai-agents-python','modelcontextprotocol/go-sdk','mistralai/mistral-common','huggingface/peft','SWE-agent/SWE-ReX','anthropics/claude-agent-sdk-python','OpenHands/software-agent-sdk']
chart = ''.join(bar(by_slug[s]) for s in top)
chart_all = ''.join(bar(by_slug[s]) for s in sorted(selected-set(top),key=str.lower))
labhtml = []
for i, lab in enumerate(labs,1):
    content = render(lab['markdown'])
    content = re.sub(r'^<h3[^>]*>.*?</h3>','',content,count=1,flags=re.S)
    # Keep issues readable; put the long audit trail behind its own disclosure.
    content = re.sub(r'(<h4[^>]*>.*?</h4>)(.*?)(<p><strong>Issue candidates)',r'\1<details class="evidence"><summary>Measurements, policy files, CI and affiliation evidence</summary>\2</details>\3',content,flags=re.S)
    search = html.escape(lab['name']+' '+' '.join(lab['slugs']),quote=True)
    labhtml.append(f'<details class="lab" data-search="{search.lower()}"><summary><span class="lab-number">{i:02}</span><span>{html.escape(lab["name"])}</span><span class="lab-count">{len(lab["slugs"])} surfaces</span></summary><div class="lab-body">{content}</div></details>')

css = (ROOT/'research/report.css').read_text()
js = """
const root=document.documentElement;
const toggle=document.querySelector('#theme-toggle');
function setTheme(theme){root.dataset.theme=theme;toggle.textContent=theme==='dark'?'Light theme':'Dark theme';toggle.setAttribute('aria-pressed',String(theme==='dark'));try{localStorage.setItem('oss-theme',theme)}catch{}}
let saved;try{saved=localStorage.getItem('oss-theme')}catch{}
setTheme(saved==='light'||saved==='dark'?saved:(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'));
toggle.addEventListener('click',()=>setTheme(root.dataset.theme==='dark'?'light':'dark'));
const labs=[...document.querySelectorAll('details.lab')];
document.querySelector('#lab-search').addEventListener('input',event=>{const term=event.target.value.trim().toLowerCase();let count=0;for(const lab of labs){const show=lab.dataset.search.includes(term);lab.hidden=!show;if(show)count++}document.querySelector('#lab-result').textContent=count+' of 32 groups';});
document.querySelector('#expand-labs').addEventListener('click',()=>labs.filter(l=>!l.hidden).forEach(l=>l.open=true));
document.querySelector('#collapse-labs').addEventListener('click',()=>labs.forEach(l=>l.open=false));
document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',()=>{const target=document.getElementById(a.getAttribute('href').slice(1));if(target){for(let p=target.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;}}));
"""
origin_path=ROOT/'research/site-origin.txt'
origin=origin_path.read_text().strip() if origin_path.exists() else ''
og = f'<meta property="og:image" content="{origin}/og.png"><meta name="twitter:image" content="{origin}/og.png">' if origin and (ROOT/'public/og.png').exists() else ''
page = f'''<!doctype html>
<html lang="en" data-theme="light"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="light dark">
<title>AI Lab OSS Field Guide — Rohan Patnaik</title><meta name="description" content="An evidence-backed open-source contribution strategy: 32 lab and project groups, 81 code surfaces, 31 issue leads, and a six-PR portfolio for Rohan Patnaik.">
<meta property="og:title" content="AI Lab OSS Field Guide"><meta property="og:description" content="81 code surfaces. Issue-led fixes. One focused six-PR portfolio."><meta property="og:type" content="website"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="AI Lab OSS Field Guide"><meta name="twitter:description" content="81 code surfaces. Issue-led fixes. One focused six-PR portfolio.">{og}<style>{css}</style></head>
<body><a class="skip-link" href="#main">Skip to report</a><header class="topbar"><a class="brand" href="#overview"><span class="brand-mark">↗</span> OSS / FIELD GUIDE</a><nav aria-label="Main navigation"><a href="#portfolio">Portfolio</a><a href="#labs">Repositories</a><a href="#history">Your history</a></nav><button id="theme-toggle" type="button" aria-pressed="false">Dark theme</button></header>
<main id="main"><section class="hero" id="overview"><div class="eyebrow">ISSUE-RESOLUTION EDITION · 19 SEPTEMBER 2026 IST</div><h1>AI Lab OSS<br><span>Field Guide.</span></h1><p class="hero-deck">Build a hiring signal through useful, reviewed engineering.</p><p class="byline">Prepared for <a href="https://github.com/rohan-patnaik">Rohan Patnaik</a> · Python / Go / TypeScript</p><div class="hero-links"><a class="primary-link" href="#portfolio">Start with the six-PR plan <span>↓</span></a><a href="report.md" download>Download Markdown</a><a href="report.html" download>Save standalone HTML</a></div></section>
<div class="stat-grid" aria-label="Research summary"><div class="stat"><span>CODE SURFACES RETAINED</span><strong>81</strong><small>32 groups · 15 content repos removed</small></div><div class="stat"><span>YOUR MERGED PRs</span><strong>14<span> / 47</span></strong><small>15 open · 18 closed without merge</small></div><div class="stat"><span>REPORTED FAILURE LEADS</span><strong>31</strong><small>21 repos · reproduction/approval gates</small></div><div class="stat"><span>FOCUSED PORTFOLIO</span><strong>6</strong><small>2 LOW · 2 MEDIUM · 2 HIGH</small></div></div>
<aside class="notice"><strong>A snapshot, not a reservation.</strong> Re-check every issue before claiming it. External share measures the composition of merged PRs—not your acceptance probability. Hidden employment and unlinked competing work remain uncertain. <a href="#method">Read the method and limits →</a></aside>
<section class="decision prose">{render(sections['Decision in one page'])}</section>
<section class="report-section" id="chart"><div class="section-heading"><span class="eyebrow">OBSERVED MERGED WORK</span><h2>Where outsiders appear in recent merges</h2><p>Affiliation-adjusted candidate external PRs / non-bot PRs. Up to 100 most recent merges per repo. 18 September snapshot; small samples and policy gates matter.</p></div><div class="chart">{chart}</div><details class="chart-more"><summary>Show the other 71 code surfaces</summary><div class="chart">{chart_all}</div></details><p class="caption">E/H is a proxy, not verified employment or an acceptance rate. Exact counts, windows, latency, backlog and source PRs are in each lab dossier. <a href="metrics.json">Download measurements</a>.</p></section>
{section('The six-PR portfolio','portfolio')}
{section('Issue-first rules and complaint discovery','issue-first')}
<section class="report-section" id="labs"><div class="section-heading"><span class="eyebrow">32 GROUPS / 81 CODE SURFACES</span><h2>The repository field guide</h2><p>Open a group for up to three code surfaces, contribution rules, queue measurements and actual failure reports. DISCOVERY ONLY means no suitable issue was verified; AVOID marks a policy or maintenance blocker.</p></div><div class="lab-tools"><label for="lab-search">Find a lab or repository<input type="search" id="lab-search" placeholder="Try OpenAI, MCP, Go or DeepMind"></label><div class="lab-buttons"><button type="button" id="expand-labs">Expand visible</button><button type="button" id="collapse-labs">Collapse all</button></div><span id="lab-result" role="status" aria-live="polite">32 of 32 groups</span></div><div class="legend"><span class="badge low">LOW</span> small, issue-backed fixes <span class="badge medium">MEDIUM</span> bounded behavior <span class="badge high">HIGH</span> deeper correctness / recovery</div>{''.join(labhtml)}</section>
{section('Your contribution history: what the evidence says','history')}
{section('How to maximize actual merge probability','merge-guide')}
{section('Practical order of attack','schedule')}
{section('Repositories and surfaces to avoid','avoid') if 'Repositories and surfaces to avoid' in sections else section(next(k for k in sections if 'avoid' in k.lower()),'avoid')}
<section class="report-section" id="inventory"><details class="large-disclosure"><summary>Full inventory: all 47 external PRs</summary>{render(sections['Complete authored external PR inventory'])}</details></section>
{section('Measurement method and evidence limits','method')}
{section('Evidence downloads','downloads')}
<footer><span>AI LAB OSS FIELD GUIDE · ISSUE REVISION 19 SEP IST / METRICS 18 SEP 2026</span><a href="#overview">Back to top ↑</a><p>Public GitHub evidence, explicit uncertainty, and a focused engineering plan. No issue comments, PRs or CLA signatures were submitted by this research task.</p></footer></main><script>{js}</script></body></html>'''
(ROOT/'public/report.html').write_text(page)
(ROOT/'app/report-page.json').write_text(json.dumps(page))
print(f'Standalone HTML: {len(page):,} characters; no external runtime assets')
