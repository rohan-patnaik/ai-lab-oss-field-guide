import json,sys
from pathlib import Path
slugs=sys.argv[1:] or ['openai/openai-agents-python','openai/openai-agents-js','modelcontextprotocol/go-sdk','mistralai/mistral-common','huggingface/peft','EleutherAI/lm-evaluation-harness','vllm-project/semantic-router','OpenHands/software-agent-sdk','SWE-agent/mini-swe-agent','google-gemini/gemini-cli','anthropics/claude-agent-sdk-python']
for slug in slugs:
 p=Path('research/raw')/(slug.replace('/','__')+'.json')
 if not p.exists():continue
 d=json.loads(p.read_text());print('\n##',slug)
 for a in d['issues']['nodes']:
  if a['assignees']['nodes']:continue
  refs=[n.get('source',n.get('subject',{})) for n in a.get('timelineItems',{}).get('nodes',[])];prs=[r for r in refs if r.get('__typename')=='PullRequest']
  if prs:continue
  print(a['number'],a['title'],[l['name'] for l in a['labels']['nodes']],'|',a['body'][:480].replace('\n',' '))
