"""Refresh issue eligibility for the issue-resolution-only revision."""
from collect import gql, ROOT
import concurrent.futures
import datetime
import json
import sys

TARGETS = {
 'modelcontextprotocol/python-sdk':[3545,3544,3526,3505],
 'modelcontextprotocol/go-sdk':[1263],
 'google-deepmind/mujoco':[3596,3585],
 'PrimeIntellect-ai/prime':[876],
 'pytorch/torchtitan':[4783],
 'pytorch/ao':[4904],
 'mistralai/client-python':[625],
 'huggingface/transformers':[48887],
 'allenai/open-instruct':[1899],
 'EleutherAI/lm-evaluation-harness':[2614,2289,2371,3120],
 'EleutherAI/sae':[130],
 'deepseek-ai/smallpond':[29],
 'SakanaAI/AI-Scientist':[251],
 'NousResearch/tinker-atropos':[30],
 'NVIDIA/NeMo':[16278],
 'NVIDIA/TensorRT-LLM':[18662],
 'vllm-project/vllm':[57475,57578],
 'OpenHands/software-agent-sdk':[4670,4731,5074,4990,5067,5038,4910,5091,4983,5096,4912,4965,5094],
 'block/buzz':[7737],
 'Aider-AI/aider':[5729],
 'Aider-AI/polyglot-benchmark':[13,11],
 'cline/cline':[14253],
 'cline/kanban':[644],
 'SWE-agent/SWE-ReX':[241,279,175],
}
PORTFOLIO = {
 'EleutherAI/lm-evaluation-harness':[2614,2289],
 'SWE-agent/SWE-ReX':[241,279],
 'modelcontextprotocol/python-sdk':[3545,3544],
 'OpenHands/software-agent-sdk':[4670,4731,5074,4990],
 'google-deepmind/mujoco':[3596,3585],
}
REFRESH = '--refresh' in sys.argv
OUT=ROOT/'revision'/'issue-audit'
OUT.mkdir(parents=True,exist_ok=True)

def check(item):
    slug, number = item
    path=OUT/f'{slug.replace("/","__")}__{number}.json'
    if path.exists() and not REFRESH:return json.loads(path.read_text())
    owner,name=slug.split('/');cursor=None;events=[]
    while True:
        query='query{repository(owner:'+json.dumps(owner)+',name:'+json.dumps(name)+'){issue(number:'+str(number)+'){number title url state body author{login} authorAssociation assignees(first:100){nodes{login}} labels(first:60){nodes{name}} comments(last:100){totalCount nodes{author{login} authorAssociation body url createdAt}} timelineItems(first:100,itemTypes:[CROSS_REFERENCED_EVENT,CONNECTED_EVENT]'+(',after:'+json.dumps(cursor) if cursor else '')+'){pageInfo{hasNextPage endCursor} nodes{__typename ...on CrossReferencedEvent{source{__typename ...on PullRequest{number title url state}}} ...on ConnectedEvent{subject{__typename ...on PullRequest{number title url state}}}}}}}}'
        issue=gql(query)['repository']['issue'];tl=issue['timelineItems'];events+=tl['nodes']
        if not tl['pageInfo']['hasNextPage']:break
        cursor=tl['pageInfo']['endCursor']
    issue['timelineItems']['nodes']=events
    issue['linkedPRs']=[n.get('source',n.get('subject',{})) for n in events if n.get('source',n.get('subject',{})).get('__typename')=='PullRequest']
    issue['checkedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    if number in PORTFOLIO.get(slug,[]):
        q=f'repo:{slug} is:pr "{number}" in:body'
        issue['competitionSearch']=gql('query{search(type:ISSUE,query:'+json.dumps(q)+',first:50){issueCount nodes{...on PullRequest{number title url state body}}}}')['search']
    path.write_text(json.dumps(issue,indent=2))
    return issue

if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        for x in pool.map(check,[(s,n) for s,ns in TARGETS.items() for n in ns]):
            print(x['url'],x['state'],'assigned',len(x['assignees']['nodes']),'PRrefs',len(x['linkedPRs']),'search',x.get('competitionSearch',{}).get('issueCount'),flush=True)
