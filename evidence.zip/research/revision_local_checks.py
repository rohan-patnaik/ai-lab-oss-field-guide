"""Repeat two limited checks against the saved, pinned harness source.

This deliberately does not install upstream dependencies, run a model, or claim
that source confirmation alone proves end-to-end user impact.
"""
import ast
import datetime
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'revision'
SOURCE = ROOT / 'source'
PREFIX = 'EleutherAI__lm-evaluation-harness'
metadata = json.loads((SOURCE / (PREFIX + '.json')).read_text())
source = (SOURCE / (PREFIX + '__lm_eval__filters__extraction.py')).read_text()
tree = ast.parse(source)
cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'RegexFilter')
cls.bases = []
cls.decorator_list = []
module = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), cls], type_ignores=[])
ast.fix_missing_locations(module)
namespace = {'re': re}
exec(compile(module, '<saved RegexFilter, base/decorator removed>', 'exec'), namespace)
input_text = '    return 1'
output = namespace['RegexFilter'](regex_pattern=r'(    return 1)').apply([[input_text]], [{}])[0][0]
tags = {}
for language in ['en_cot', 'native_cot']:
    text = (SOURCE / f'{PREFIX}__lm_eval__tasks__mgsm__{language}__cot_yaml').read_text()
    tags[language] = re.search(r'^tag:\s*(.+)$', text, re.M).group(1)
results = {
    'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command': 'python3 research/revision_local_checks.py',
    'repo_sha': metadata['data']['defaultBranchRef']['target']['oid'],
    'results': [
        {'issue': 'https://github.com/EleutherAI/lm-evaluation-harness/issues/2371',
         'check': 'isolated saved current RegexFilter class; decorator/base removed to avoid unrelated dependencies',
         'input': input_text, 'output': output, 'whitespace_preserved': output == input_text,
         'limit': 'Transformation only. No end-to-end HumanEval run or agreed replacement semantics.'},
        {'issue': 'https://github.com/EleutherAI/lm-evaluation-harness/issues/2614',
         'check': 'saved current source template tags', **tags,
         'distinct': tags['en_cot'] != tags['native_cot'],
         'limit': 'Template-level confirmation, not full task-manager or model evaluation.'},
    ],
}
(ROOT / 'local-checks.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
