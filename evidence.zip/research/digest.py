import json,glob,re,sys
allpaths=sorted(glob.glob('research/policies/*/index.json'))
start=int(sys.argv[1]) if len(sys.argv)>1 else 0
for p in allpaths[start:start+12]:
 d=json.load(open(p));slug=p.split('/')[-2].replace('__','/');print('\n###',slug)
 for a in d['files']:
  if 'error' in a:continue
  path=a['path'];t=open(p.replace('index.json',a['file'])).read()
  if not re.search(r'contribut|pull_request_template|^readme|^cla\.',path,re.I):continue
  lines=t.splitlines();kept=[]
  for i,l in enumerate(lines):
   if re.search(r'CLA\b|DCO\b|sign.off|agreement|issue|generat(?:ed|ion)|stainless|fern|speakeasy|copybara|accept|AI.assist|AI.generat|pull request|maintain|pytest|npm run|pnpm|make check',l,re.I):
    if path.lower()=='readme.md' and not re.search(r'contribut|generated|stainless|fern|speakeasy|copybara|not accept|maintain',l,re.I):continue
    kept.append(f'{i+1}: {l}')
  print(path+'\n'+'\n'.join(kept)[:2800])
