from collect import *
import statistics,collections
MCP_MAINTAINERS=set(re.findall(r'https://github.com/([A-Za-z0-9_-]+)\)',(ROOT/'mcp-maintainers.md').read_text()))
OWNER_PAT={
'openai':r'openai','anthropics':r'anthropic', 'modelcontextprotocol':r'modelcontextprotocol',
'google-gemini':r'google|deepmind','google-deepmind':r'google|deepmind','googleapis':r'google|deepmind',
'xai-org':r'\bxai\b|x\.ai','cognitionai':r'cognition','cursor':r'cursor|anysphere','anysphere':r'cursor|anysphere',
'agentica-project':r'agentica','togethercomputer':r'together','primeintellect-ai':r'prime.?intellect',
'pytorch':r'\bmeta\b|facebook|pytorch','meta-pytorch':r'\bmeta\b|facebook|pytorch','microsoft':r'microsoft',
'mistralai':r'mistral','huggingface':r'hugging.?face','cohere-ai':r'cohere','allenai':r'allenai|\bai2\b|allen institute',
'eleutherai':r'eleuther','deepseek-ai':r'deepseek','qwenlm':r'qwen|alibaba','unslothai':r'unsloth','sakanaai':r'sakana',
'perplexityai':r'perplexity','nousresearch':r'nous.?research','nvidia':r'nvidia',
'openhands':r'openhands|all.?hands','block':r'\bblock\b|\bsquare\b','aider-ai':r'\baider\b','cline':r'\bcline\b','continuedev':r'continuedev|\bcontinue\b',
'vllm-project':r'vllm','sgl-project':r'sglang','swe-agent':r'swe-agent'}
def classify(p,slug):
 u=p.get('author');owner=slug.split('/')[0].lower()
 if not u:return 'unknown','deleted author'
 login=u['login'];low=login.lower()
 if u['__typename']!='User' or re.search(r'\[bot\]|(?:^|[-_])(bot|jambot)$|^(copybara|copyberry|dependabot|github-actions|stainless|fern-bot)',low):return 'bot','bot type/name'
 if owner=='modelcontextprotocol' and login in MCP_MAINTAINERS:return 'affiliated','listed official MCP maintainer'
 if p['authorAssociation'] in ['MEMBER','OWNER']:return 'affiliated','GitHub '+p['authorAssociation']
 orgs=[o['login'].lower() for o in u.get('organizations',{}).get('nodes',[])]
 if owner in orgs:return 'affiliated','public org membership'
 pat=OWNER_PAT.get(owner,re.escape(owner));company=u.get('company') or '';bio=u.get('bio') or ''
 if owner=='continuedev' and login=='RomneyDa':return 'privileged','profile says former Continue founding engineer; affiliation at merge uncertain, excluded conservatively'
 if owner=='nvidia-nemo':pat=r'nvidia'
 if re.search(pat,company,re.I):return 'affiliated','public company: '+company
 # Current-job statements only; generic mentions/contributor bios and previous jobs do not count.
 if re.search(r'(?:engineer|research|work(?:ing)?|\bat|building|founder|developer|maintain\w*|MLE)\s+(?:at\s+|@\s*)?'+pat,bio,re.I) and not re.search(r'(previous|formerly|\bex[- ]).*'+pat,bio,re.I):return 'affiliated','current-work profile: '+bio[:160]
 if owner=='anthropics' and (low.endswith('-ant') or low.startswith('ant-')):return 'inferred_affiliated','Anthropic-style account suffix/prefix; employment unverified'
 if owner=='openai' and low.endswith('-oai'):return 'inferred_affiliated','OpenAI-style account suffix; employment unverified'
 if p['authorAssociation']=='COLLABORATOR':return 'privileged','collaborator; employment unknown'
 return 'external_candidate','no public owning-org affiliation found; not proof of external employment'
def dt(x):return datetime.datetime.fromisoformat(x.replace('Z','+00:00'))
NOW=datetime.datetime.now(datetime.timezone.utc)
def analyze(slug):
 f=ROOT/'raw'/(slug.replace('/','__')+'.json')
 if not f.exists():return {'slug':slug,'missing':True}
 d=json.loads(f.read_text());prs=d.get('exactMerged',d['merged']['nodes']);counts=collections.Counter();ext=[];corrections=[]
 for p in prs:
  c,why=classify(p,d['nameWithOwner']);counts[c]+=1
  if c=='external_candidate':ext.append(p)
  if c in ['affiliated','inferred_affiliated'] and p['authorAssociation'] not in ['MEMBER','OWNER']:corrections.append({'login':p['author']['login'],'profile':p['author']['url'],'reason':why,'pr':p['url']})
 humans=len(prs)-counts['bot'];oe=[p for p in d['open']['nodes'] if classify(p,d['nameWithOwner'])[0]=='external_candidate'];oe.sort(key=lambda p:p['createdAt'])
 result={'slug':slug,'canonical':d['nameWithOwner'],'url':d['url'],'stars':d['stargazerCount'],'language':(d['primaryLanguage'] or {}).get('name','—'),'archived':d['isArchived'],'description':d['description'],'pushedAt':d['pushedAt'],'sample':len(prs),'human':humans,'bots':counts['bot'],'counts':dict(counts),'external':len(ext),'share':round(100*len(ext)/humans,1) if humans else None,'allShare':round(100*len(ext)/len(prs),1) if prs else None,'medianDays':round(statistics.median((dt(p['mergedAt'])-dt(p['createdAt'])).total_seconds()/86400 for p in ext),2) if ext else None,'openPRs':d['open']['totalCount'],'oldestExternal': [{'url':p['url'],'title':p['title'],'createdAt':p['createdAt'],'ageDays':(NOW-dt(p['createdAt'])).days} for p in oe[:3]],'oldestCensored':not oe and d['open']['pageInfo']['hasNextPage'],'sampleComplete':d.get('exactMergedComplete',len(prs)<100),'sampleStart':min((p['mergedAt'] for p in prs),default=None),'sampleEnd':max((p['mergedAt'] for p in prs),default=None),'examples':[{'url':p['url'],'title':p['title'],'author':p['author']['login']} for p in ext[:3]],'corrections':list({x['login']:x for x in corrections}.values()),'issuesTotal':d['issues']['totalCount'],'collectedAt':d['collectedAt']}
 return result
if __name__=='__main__':
 ds=[analyze(s) for s in dict.fromkeys(sum(CAT.values(),[])+AVOID)];(ROOT/'metrics.json').write_text(json.dumps(ds,indent=2))
 for d in ds:
  if d.get('missing'):print(d['slug'],'MISSING');continue
  print(d['canonical'],d['external'], '/',d['human'],f"{d['share']}%",'median',d['medianDays'],'open',d['openPRs'],'oldest',next(iter(d['oldestExternal']),{}).get('ageDays'),'ARCHIVED' if d['archived'] else '')
