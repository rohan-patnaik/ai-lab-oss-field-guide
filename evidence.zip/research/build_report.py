"""Assemble the Markdown report from saved public GitHub evidence."""
import json
import re
from pathlib import Path
from collect import CAT
from annotations import NOTES

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
METRICS = {m['slug']: m for m in json.loads((ROOT/'metrics.json').read_text())}
ISSUES = json.loads((ROOT/'verified-shortlist.json').read_text())

def clean(text):
    return str(text).replace('|', '\\|').replace('\n', ' ')

def policy(slug):
    folder = ROOT/'policies'/slug.replace('/', '__')
    index = json.loads((folder/'index.json').read_text())
    files = [f for f in index['files'] if re.search(r'contribut|pull_request_template|^README|^AGENTS|^CLA(?:\.|$)|^DCO(?:\.|$)|^\.github/(?:workflows/|CODEOWNERS)', f['path'], re.I)]
    sources = [f for f in files if not f['path'].startswith('.github/workflows/')]
    workflows = [f for f in files if f['path'].startswith('.github/workflows/')]
    cla, dco = [], []
    for f in files:
        text = (folder/f['file']).read_text()
        if re.search(r'\bCLA\b|contributor license agreement|contribution agreement|cla-assistant', text, re.I): cla.append(f)
        if re.search(r'\bDCO\b|developer certificate of origin|signed-off-by|git commit -s\b', text, re.I): dco.append(f)
    def link(f, label=None): return f"[{label or f['path']}]({f['url']})"
    agreements = []
    if cla: agreements.append(link(cla[0], 'CLA/agreement documented'))
    if dco: agreements.append(link(dco[0], 'DCO/sign-off documented'))
    agreement = '; '.join(agreements) or 'CLA/DCO not established in inspected files'
    return index, sources, workflows, agreement, link

def dossier(lab, slugs):
    out = [f'### {lab}', '', 'Ranked surfaces for your skill fit; WATCH/AVOID rows are not an endorsement of current intake.', '',
           '| Repo / verdict | Stars · language | External merged share | External median | Open PRs · oldest candidate external | CLA / policy and fit |',
           '|---|---|---|---|---|---|']
    for slug in slugs:
        m = METRICS[slug]; status, fit, rules = NOTES[slug]
        idx, sources, workflows, agreement, link = policy(slug)
        oldest = m['oldestExternal']
        age = f"[{oldest[0]['ageDays']} d]({oldest[0]['url']})" if oldest else ('unverified beyond first 100' if m['oldestCensored'] else 'none identified in scanned set')
        share = f"{m['external']}/{m['human']} = {m['share']}%" if m['human'] else 'N/A (no human sample)'
        median = str(m['medianDays'])+' d' if m['medianDays'] is not None else 'N/A'
        out.append(f"| [{slug}]({m['url']}) · **{status}** | {m['stars']:,} · {m['language']} | {share} | {median} | [{m['openPRs']:,}]({m['url']}/pulls) · {age} | {agreement}. {clean(rules)} **Fit:** {clean(fit)} |")
    for slug in slugs:
        m = METRICS[slug]; idx, sources, workflows, agreement, link = policy(slug)
        out += ['',f"#### {slug}", '']
        if slug != m['canonical']: out.append(f"**Canonical repository:** [{m['canonical']}]({m['url']}) (GitHub redirect from the screened name).\n")
        period = f"{(m['sampleStart'] or 'N/A')[:10]} to {(m['sampleEnd'] or 'N/A')[:10]}"
        out.append(f"**Sample:** N={m['sample']}, bots={m['bots']}, human/unresolved={m['human']}, candidate external={m['external']}; merges {period}. {'Exact most-recent cohort recovered.' if m['sampleComplete'] else 'Incomplete cohort: do not treat as an exact last-100 result.'} Snapshot {m['collectedAt'][:19]} UTC. [Saved metrics](metrics.json) and [raw API evidence + collector](evidence.zip).")
        if m['examples']: out.append('**Recent candidate-external examples:** '+ '; '.join(f"[#{x['url'].split('/')[-1]}: {clean(x['title'])}]({x['url']})" for x in m['examples'])+'.')
        if m['oldestExternal']: out.append('**Oldest observed external queue entries:** '+ '; '.join(f"[#{x['url'].split('/')[-1]}]({x['url']}) ({x['ageDays']} d; opened {x['createdAt'][:10]})" for x in m['oldestExternal'])+'.')
        out += ['', '**Policy sources at pinned commit:** '+ ('; '.join(link(f) for f in sources) if sources else 'No relevant guide/template/README found in this tree.')+'.']
        contribution = [f for f in sources if 'contribut' in f['path'].lower()]
        templates = [f for f in sources if 'pull_request_template' in f['path'].lower()]
        if not contribution: out.append('No CONTRIBUTING file found in the inspected tree; missing policy is not permission.')
        if not templates: out.append('No repository-local PR template found; inherited organization templates were not fully audited.')
        out.append('**CI inspected:** '+ ('; '.join(link(f) for f in workflows) if workflows else 'No GitHub Actions workflow found in the inspected tree; other/private CI is unverified.')+'.')
        if m['corrections']:
            unique = {}; [unique.setdefault(x['login'],x) for x in m['corrections']]
            out.append('**Affiliation adjustments:** '+ '; '.join(f"[{x['login']}]({x['profile']}) — {clean(x['reason'])}" for x in unique.values())+'. Evidence is public profile/core-role information at collection time, not proof of employment when each PR merged.')
        out += ['', '**Issue candidates — re-check within hours:**', '']
        for level in ['LOW','MEDIUM','HIGH']:
            picks = ISSUES[slug].get(level, ISSUES[slug].get('MED',[]) if level=='MEDIUM' else [])
            if not picks:
                out.append(f'- **{level}:** No clean candidate verified in the inspected issue pool. Do not invent work to fill this bucket.')
            for issue in picks:
                audit = issue['audit']; labels = ', '.join(x['name'] for x in audit['labels']['nodes']) or 'none'
                count = audit['comments']['totalCount']
                extra = ' More than 100 comments: older discussion not fully inspected.' if count>100 else ''
                out.append(f"- **{level}:** [#{issue['number']} — {clean(issue['title'])}]({issue['url']}). Checked {audit['checkedAt'][:19]} UTC: OPEN, 0 assignees, 0 linked PRs in complete timeline. Labels: {clean(labels)}. Scope and maintainer acceptance still need confirmation.{extra}")
    return '\n'.join(out)

def build():
    narrative = (ROOT/'narrative.md').read_text()
    intro, method = narrative.split('## Measurement method and evidence limits', 1)
    chunks = [intro, '## Repository field guide\n\nThe table order reflects skill fit and intake evidence, not star rank. Popularity and activity are measured separately. Each group has three screened rows; where a lab has no credible open intake, the result says so. **LOW / MEDIUM / HIGH measure proposed scope and engineering importance, not likelihood of review.** Issues can move categories after reproduction.\n']
    labs = []
    for lab, slugs in CAT.items():
        content = dossier(lab, slugs); chunks.append(content); labs.append({'name':lab,'slugs':slugs,'markdown':content})
    chunks.append('## Complete authored external PR inventory\n\nAll 47 results from the stated public query, checked using individual PR metadata. Closed does not imply rejected; consult the reason table above.\n\n| PR | Title | State | Created | Merged / closed |\n|---|---|---|---|---|')
    history = [json.loads(p.read_text()) for p in (ROOT/'raw').glob('history__*.json')]
    history.sort(key=lambda r:r['created_at'],reverse=True)
    for r in history:
        state = 'MERGED' if r['merged_at'] else r['state'].upper()
        repo = r['html_url'].split('github.com/')[1].split('/pull/')[0]
        chunks.append(f"| [{repo} #{r['number']}]({r['html_url']}) | {clean(r['title'])} | {state} | {r['created_at'][:10]} | {(r['merged_at'] or r['closed_at'] or '—')[:10]} |")
    chunks.append('## Measurement method and evidence limits'+method)
    chunks.append('## Evidence downloads\n\n[Machine-readable repository metrics](metrics.json) · [Verified issue shortlist](issues.json) · [Public API snapshots, pinned policy files and executable collectors](evidence.zip). All factual findings are tied to the linked upstream record or these command results; recommendations and effort estimates are editorial judgments.\n')
    report = '\n\n'.join(chunks)+'\n'
    (PROJECT/'report.md').write_text(report)
    (PROJECT/'public/report.md').write_text(report)
    (ROOT/'labs.json').write_text(json.dumps(labs,indent=2))
    print(f'Markdown written first: {len(report):,} characters; {len(labs)} groups; {len(history)} PRs')

if __name__=='__main__': build()
