# AI Lab OSS Field Guide

**Prepared for [Rohan Patnaik](https://github.com/rohan-patnaik) · Live GitHub research, 18 September 2026 · Python / Go / TypeScript, with Rust and C++ stretch work.**

## Decision in one page

Build a coherent signal around **reliable agent execution, trustworthy evaluation and ML infrastructure**. A maintainer-reviewed fix with a reproducer and a clear compatibility argument is stronger evidence than a large count of cosmetic PRs. This is an engineering recommendation, not evidence that any lab promises interviews for contributions.

The six-PR plan below uses **SWE-ReX, LM Evaluation Harness, vLLM Production Stack, OpenHands SDK and DeepMind MuJoCo**. It gives you two small completions, two bounded behavior changes and two deeper ownership stories. MuJoCo is the C++ stretch; the other primary tasks are Python-facing. Work on at most two implementation PRs at once, and discuss the high-scope work early.

Keep **OpenAI Agents Python, MCP Go, Mistral Common and Hugging Face PEFT** on your watchlist. They fit your skills, but the screened issue pools did not yield a clean primary/fallback pair without competition, ownership ambiguity or a policy gate. Do not force a direct OpenAI/Anthropic PR just to obtain the logo. The dossier below shows current evidence and issue gaps.

**Reading the tables:** PURSUE means a good repository-level fit, not an already approved issue. CONDITIONAL means a policy, hardware or scope gate. WATCH means sparse, stale or ambiguous intake evidence. AVOID means a current policy or maintenance blocker. The three rows per group are the best screened surfaces in this audit; some groups do not have three defensible recommendations. Those rows remain explicitly WATCH/AVOID rather than being presented as realistic bets.

**Availability expires quickly.** Every listed candidate was open and unassigned with no PullRequest reference in the fully paginated issue timeline at its audit time. This does not reserve it. Re-check assignment, all comments, linked/competing PRs and current source immediately before commenting or coding. Informal claims, unsupported product requests, and obvious issue noise were screened out where identified. A candidate is an investigation, not a reproduced defect or maintainer approval.

## Your contribution history: what the evidence says

The refreshed public upstream query returns **47 PRs: 14 merged, 15 open, 18 closed without a GitHub merge**. The older estimate of about 25 is out of date. Definition: public PRs authored by `rohan-patnaik`, excluding repositories owned by `rohan-patnaik`. The result includes lab-adjacent and other upstream organizations, not just the five companies named in the prompt. [Live search](https://github.com/search?q=is%3Apr+author%3Arohan-patnaik+-user%3Arohan-patnaik+is%3Apublic&type=pullrequests).

That is **29.8% merged among all opened PRs**, or **43.8% among the 32 resolved PRs**. Neither is a forecast: the 15 pending PRs are censored, task selection changed over time, and GitHub's merge state misses work ported into replacement commits. Counts were derived from the saved search result plus individual PR metadata; the complete linked inventory follows the guide.

Your history supports Python, Go and TypeScript maintenance work. Existing merges are more useful than an invented beginner narrative: show the concrete defect, test and maintainer discussion. The rejection review suggests the biggest improvement is **scope and validation before implementation**, not writing more code faster.

### Closed PRs: verified reasons and limits

| PR | Evidence / reason | What to change next time |
|---|---|---|
| [OSV Scanner #2878](https://github.com/google/osv-scanner/pull/2878), [#2879](https://github.com/google/osv-scanner/pull/2879), [#2880](https://github.com/google/osv-scanner/pull/2880) | Maintainer explicitly said to read the contribution guide before opening PRs. [Comment](https://github.com/google/osv-scanner/pull/2879#issuecomment-4679158223). The comment alone does not specify every rule missed. | Turn the current guide and template into a short intake checklist before coding. |
| [Playwright Python #3085](https://github.com/microsoft/playwright-python/pull/3085) | Generated wrapper files were edited by hand. [Maintainer comment](https://github.com/microsoft/playwright-python/pull/3085#issuecomment-4646353709). Your follow-up identified upstream metadata fixed in [Playwright #41183](https://github.com/microsoft/playwright/pull/41183). | Locate the source schema/generator and its language filters; regenerate and test. |
| [Playwright #40994](https://github.com/microsoft/playwright/pull/40994) | Browser-patch changes had not been built and runtime-tested against patched Firefox. [Maintainer explanation](https://github.com/microsoft/playwright/pull/40994#issuecomment-4542620368). | Only choose a native/GPU/browser change when you can execute the modified artifact. |
| [Playwright Python #3100](https://github.com/microsoft/playwright-python/pull/3100) | Maintainer preferred retaining strict Python decoding semantics pending stronger demand. [Decision](https://github.com/microsoft/playwright-python/pull/3100#issuecomment-4660036966). | Cross-language parity is not automatically the intended contract. Ask which behavior should win. |
| [Azure CLI #33483](https://github.com/Azure/azure-cli/pull/33483) | The proposed experimental status was being deprecated. [Maintainer roadmap clarification](https://github.com/Azure/azure-cli/pull/33483#issuecomment-4608117267). | Confirm the issue still matches the roadmap; an open issue is not approval. |
| [Docusaurus #12053](https://github.com/facebook/docusaurus/pull/12053) | Reviewer considered computed-style handling too complex; later suggested an override direction. [Review](https://github.com/facebook/docusaurus/pull/12053#pullrequestreview-4346562235), [follow-up](https://github.com/facebook/docusaurus/pull/12053#issuecomment-4742886295). This is evidence about the approach, not proof the underlying need was rejected. | Agree on the smallest supported behavior and avoid general frameworks for a narrow edge case. |
| [Playwright #40999](https://github.com/microsoft/playwright/pull/40999) | Closure points to an earlier decision that the approach was wrong and a maintainer was implementing the proper fix. [Closure](https://github.com/microsoft/playwright/pull/40999#issuecomment-4545496774), [referenced decision](https://github.com/microsoft/playwright/pull/40794#issuecomment-4433254901). | Read related closed PRs and current ownership, not just the bug report. |
| [Playwright Python #3099](https://github.com/microsoft/playwright-python/pull/3099) | Tests were red; ultimately superseded by [#3135](https://github.com/microsoft/playwright-python/pull/3135). [Closure](https://github.com/microsoft/playwright-python/pull/3099#issuecomment-5035219446). | Reproduce failing OS-specific tests promptly; check competing fixes before further revisions. |
| [Jest #16207](https://github.com/jestjs/jest/pull/16207) | You closed it as superseded by [#16237](https://github.com/jestjs/jest/pull/16237), after a stale notice. [Your closure](https://github.com/jestjs/jest/pull/16207#issuecomment-5365636090). | Re-check current main and competing PRs before rebasing old work. |
| [gogcli #116](https://github.com/openclaw/gogcli/pull/116) | Reporting landed in [#554](https://github.com/openclaw/gogcli/pull/554), dedupe preview in [#555](https://github.com/openclaw/gogcli/pull/555), with co-author credit. Bidirectional sync was deferred for separate design/live proof. [Maintainer explanation](https://github.com/openclaw/gogcli/pull/116#issuecomment-4376757520). | Split behavior/risk boundaries early. Count credited replacement landings separately from merged authored PRs. |
| [Workspace CLI #786](https://github.com/googleworkspace/cli/pull/786), [#787](https://github.com/googleworkspace/cli/pull/787), [#788](https://github.com/googleworkspace/cli/pull/788) | Your follow-up says they were auto-closed for inactivity. [Example](https://github.com/googleworkspace/cli/pull/787#issuecomment-4448179049). This is author-reported, not a maintainer rejection of the implementation. | Track review cadence and stale rules; green automated reviews do not imply human approval. |
| [Playwright #40993](https://github.com/microsoft/playwright/pull/40993), [CEL-Go #1339](https://github.com/cel-expr/cel-go/pull/1339) | No explanatory review/discussion found in the fetched PR comments and reviews. | Reason unknown; do not infer low quality from the closed state. |
| [Azure CLI #33424](https://github.com/Azure/azure-cli/pull/33424) | Metadata says closed/unmerged, while a [maintainer comment](https://github.com/Azure/azure-cli/pull/33424#issuecomment-4597861342) describes the fix as shipping. Exact replacement landing not traced in this audit. | Mark landing status ambiguous, not rejected. Verify the actual commit before claiming credit. |

## The six-PR portfolio

**This is a proposal, not six reserved issues.** The twelve issue states were checked individually, all timeline references were paginated, and PR-body searches were inspected. Numeric search hits caused by dependency versions were not treated as implementations. No issue comments or PRs were posted by this research task. Estimated effort below is my planning estimate, not a measurement.

| Slot | Importance | Primary | Fallback in the same repo | Proposed boundary | Effort estimate |
|---|---|---|---|---|---|
| 1 | LOW | [SWE-ReX #92: document exceptions](https://github.com/SWE-agent/SWE-ReX/issues/92) | [#75: usage examples](https://github.com/SWE-agent/SWE-ReX/issues/75) | Document actual public exceptions with one executable example; fallback: one local/Docker usage walkthrough. | 4–8 h |
| 2 | LOW | [LM Evaluation Harness #2356: utility-script tests](https://github.com/EleutherAI/lm-evaluation-harness/issues/2356) | [#2639: main.py tests](https://github.com/EleutherAI/lm-evaluation-harness/issues/2639) | One meaningful CLI/script contract using a tiny fixture and no model download. Clarify the current entry point for the older fallback. | 6–10 h |
| 3 | MEDIUM | [vLLM Production Stack #628: Swagger request body](https://github.com/vllm-project/production-stack/issues/628) | [#785: global Helm image registry](https://github.com/vllm-project/production-stack/issues/785) | Make OpenAPI expose a useful request body while preserving router passthrough semantics; fallback: agreed chart-level registry precedence. | 8–16 h |
| 4 | MEDIUM | [OpenHands SDK #4670: silent WebSocket shutdown](https://github.com/OpenHands/software-agent-sdk/issues/4670) | [#4731: WebSocket client bundling](https://github.com/OpenHands/software-agent-sdk/issues/4731) | Deterministic shutdown and thread cleanup; fallback: a scoped browser/Node transport initialization fix after confirming that TS client remains supported. | 10–18 h |
| 5 | HIGH | [DeepMind MuJoCo #3596: actuator controls across recompile](https://github.com/google-deepmind/mujoco/issues/3596) | [#3585: integration state across recompile](https://github.com/google-deepmind/mujoco/issues/3585) | Agree on per-actuator control-block identity/width preservation and implement with native regressions; fallback is a separate state-preservation contract. | 20–35 h |
| 6 | HIGH | [OpenHands SDK #4978: typed settings/tool contracts](https://github.com/OpenHands/software-agent-sdk/issues/4978) | [#4973: typed ACP contracts](https://github.com/OpenHands/software-agent-sdk/issues/4973) | One agreed coherent contract migration, preserving serialized settings/public schemas. Both currently carry ready-for-dev. | 20–35 h |

**Why these six.** Slots 1–2 establish review habits and a useful testing/evaluation narrative. Slot 3 connects your backend skills to serving infrastructure without requiring GPU kernel expertise. Slot 4 demonstrates concurrency/resource-lifecycle reasoning: the saved current source still contained the reported five-second join and unconditional thread-reference clearing. Slot 5 provides a direct DeepMind-owned engineering contribution with physical correctness and native validation; current source still indexed controls by actuator ordinal. Slot 6 demonstrates compatibility-conscious agent API ownership. These are stronger combined signals than six unrelated one-line changes. [OpenHands source](https://github.com/OpenHands/software-agent-sdk/blob/28e8ed273617992e9556410804f54937cc059878/openhands-sdk/openhands/sdk/conversation/impl/remote_conversation.py), [MuJoCo report and pinned source links](https://github.com/google-deepmind/mujoco/issues/3596).

**Risks and go/no-go criteria.** Older test/docs issues need renewed maintainer interest. OpenHands' low adjusted external share and long queue make slots 4/6 conditional, even with concrete issues; ready-for-dev automation is not a promise from a reviewer. MuJoCo is deliberately a stretch in C++; if you cannot build the changed library and run normal plus sanitizer tests, do not open the PR. No issue was reproduced by executing upstream code in this research task. Source inspection and issue reports establish investigation targets only.

**Validation that would make each reviewable:**

- Slot 1: check each documented exception against implementation and run the example; build documentation if the repository provides a build. Avoid inventing exceptions from type names.
- Slot 2: demonstrate a failing contract before the patch or a genuinely missing regression; test output/schema and error paths, not copied implementation details. Keep fixtures deterministic and offline.
- Slot 3: assert the emitted OpenAPI schema contains the body, exercise Swagger's request against a local stub, and show existing request forwarding is unchanged. For the fallback, render Helm charts for global-only, per-image override and unset configurations.
- Slot 4: use a silent local WebSocket peer; cover immediate stop, stop after connection, repeated cycles and timeout behavior. For the fallback, validate both browser bundling and supported Node versions without unexpectedly changing the public constructor contract.
- Slot 5: run the reported zero-input, scalar and multi-input actuator cases on the modified native build; add control-identity and no-op tests. Include AddressSanitizer and the relevant existing test suite. Do not claim performance or correctness from syntax checks.
- Slot 6: snapshot/compare serialized settings and schemas; cover legacy inputs, hooks and tool registration; run relevant typing and dynamic-attribute checks. Ask to split the issue if the agreed patch becomes too broad.

## How to maximize actual merge probability

1. **Pass intake before implementation.** Read the current guide, template, CI and the most recent similar external merge. Record the approval/assignment rule in your issue note. PEFT requires explicit approval; MCP Python needs assignment/help wanted; Goose needs Ready; Gemini excludes maintainer-only work. Your OSV closures show this is a real failure mode, not paperwork.
2. **Check ownership in four places.** Inspect assignees, the issue's full discussion/timeline, open PRs and current source. “Unassigned” does not override “I have a patch ready.” Do not compete with an active contributor. PEFT's [guide](https://github.com/huggingface/peft/blob/main/docs/source/developer_guides/contributing.md) explicitly covers declared intent.
3. **Agree on behavior, then implementation.** In 4–6 sentences, give exact version/commit, minimal reproduction, expected outcome, proposed boundary and a test plan. Ask about an uncertain behavior decision. The Playwright decoding and Azure experimental-status closures show why code can be correct yet unwanted.
4. **Find the editable source.** Trace generated SDK resources, protocol schemas, docs and release files. Stainless/Fern/Speakeasy do not mean every contribution is forbidden, but the owner may need to port it through generation. Google ADK's Copybara route can close a successful PR instead of marking it merged. The per-repo generation notes identify these cases.
5. **Choose validation you can complete.** Use CPU/tiny models/local peers for initial tasks. If native, GPU or cloud execution is essential, secure access before promising a fix. State exactly what ran, what failed and what was not run. Your Firefox closure is the model example.
6. **Make one behavior easy to review.** Explain trigger → current result → desired result; keep unrelated formatting, dependencies and cleanup out. For performance, report baseline and changed results under identical conditions, including the common/no-op case. The Docusaurus and gogcli discussions show the cost of unnecessary scope.
7. **Own AI-assisted work.** Read every changed line and verify every claim, reference and command. Disclose assistance where the repository asks; never have an agent mass-file issues or comments. Follow the repo's own rule rather than a universal disclosure template. [MCP Python guidance](https://github.com/modelcontextprotocol/python-sdk/blob/main/CONTRIBUTING.md), [smolagents guidance](https://github.com/huggingface/smolagents/blob/main/CONTRIBUTING.md).
8. **Keep review moving without noise.** Respond within one or two working days when feasible. Follow the stated cadence: production-stack allows a targeted ping after five days; PEFT asks not to ping before two weeks. Else, one useful follow-up after 7–14 days is a planning recommendation, not a project rule. Link new evidence; do not send daily “any update?” messages.
9. **Measure landings, not just PR state.** Keep a ledger with issue approval, PR, tests, reviewer, merged/replacement commit and credited authorship. Record superseded work honestly. Your gogcli contribution remains useful evidence despite its original PR being closed.
10. **Turn the result into hiring evidence.** For each meaningful landing, write a short case note: user-visible failure, relevant system contract, test/benchmark, review tradeoff and final commit. Link it from your profile. Contributions can demonstrate engineering judgment; they do not establish a causal hiring probability or replace interviews and role fit.

### A comment you can adapt after doing the reproduction

> I reproduced this on `<commit/version>` with `<minimal command>`. The failure appears limited to `<boundary>`. I propose `<small change>`, preserving `<existing behavior>`, with regression coverage for `<cases>`. I checked the linked and open PRs and did not find an active implementation. Is this scope still wanted, and is anyone already working on it?

Do not paste this without the claimed reproduction. If the project asks for analysis rather than assignment requests, lead with the evidence. This report has not sent this comment anywhere.

## Practical order of attack

Assumption: **8–12 focused hours per week alongside your job**, local CPU/Docker access, and willingness to learn enough C++ to validate MuJoCo. No paid compute is assumed. The effort estimates total roughly 68–122 hours before review revisions. The calendar is a target sequence; maintainers control merge timing, so no honest plan can guarantee six merges by a particular week.

| Week | Main work | Review / decision checkpoint |
|---|---|---|
| 1 | Re-check all twelve issues. Read the five repos' current guides/templates. Confirm repository-local identity and contribution rights. Inspect your existing 15 open PRs for small actionable review requests. Reproduce slots 1–2; comment with useful evidence. Start design discussion for MuJoCo. | Verify Google CLA status; expect EleutherAI's CLA bot on first PR; set up DCO sign-off for production-stack. Do not sign on behalf of your employer without authority. |
| 2 | Open slot 1 after confirming scope; build slot 2's tiny offline test fixture. | Respond to feedback promptly. If a primary is occupied/unwanted, re-check and discuss its same-repo fallback instead. |
| 3 | Open slot 2; reproduce production-stack #628 against current main and agree on schema scope. | Aim to finish slot 1 review. Keep at most two active implementation PRs; a pending design discussion does not require another patch. |
| 4 | Open slot 3 after DCO/local checks. Reproduce the OpenHands silent-peer shutdown and post the bounded test plan. | If older issues have no human response, make one substantive follow-up per policy; do not expand the patch to attract attention. |
| 5 | Complete slot 4 tests and implementation once readiness/scope is settled. | Open slot 4 only when capacity permits; finish revisions on slots 2–3 first. Confirm MuJoCo control-preservation design before changing storage. |
| 6 | Build MuJoCo locally, run the reported native cases and add failing regressions. | Stop this slot if the changed artifact cannot be executed; use the approved same-repo fallback only if its validation is feasible. Discuss OpenHands typed-contract scope. |
| 7 | Implement slot 5's agreed control-block fix and run normal/sanitizer checks. | Ask for early design feedback through the issue; avoid a large surprise PR. |
| 8 | Open slot 5 with precise native validation; start slot 6 once earlier OpenHands feedback is addressed. | Record already merged work and final commits. If slot 4 exposed an architectural concern, resolve it before a second SDK PR. |
| 9 | Implement slot 6's coherent contract change; verify backward-compatible serialized data and public schemas. | Split scope only with maintainer agreement; one issue may legitimately need a stack, but this plan is six contribution objectives, not permission to flood PRs. |
| 10 | Open slot 6 when review capacity allows. | Rebase only when needed, rerun affected checks, and close out review requests on slots 3–5. |
| 11 | Address remaining reviews and CI; perform required live/native checks. | One appropriate follow-up for quiet PRs, according to each guide. If a task is superseded, link the replacement and stop duplicate work. |
| 12 | Finish reviews; publish concise case notes for actual landings and refresh this watchlist. | If some PRs remain unreviewed, carry them forward. Do not mark “merged” or change scope merely to meet the calendar. |

**While waiting:** reproduce another small bug locally, learn the code path, review a relevant existing PR without unsolicited noise, improve benchmark repeatability, or draft a case note. Reserve coding time for accepted work. Do not open more speculative PRs as a substitute for responding to reviewers.

**CLA/DCO details:** Google agreements are checked at [Google CLA](https://cla.developers.google.com/); EleutherAI documents its first-PR bot in the [harness guide](https://github.com/EleutherAI/lm-evaluation-harness/blob/main/docs/CONTRIBUTING.md); production-stack requires `git commit -s` in its [guide](https://github.com/vllm-project/production-stack/blob/main/CONTRIBUTING.md). A DCO sign-off and a cryptographic commit signature are different. For repositories whose inspected policy does not specify a CLA/DCO, mark it unknown and follow the maintainer/bot response rather than assuming none. No agreement was signed during this task.

## Repositories and surfaces to avoid

| Repository / surface | Current evidence and decision |
|---|---|
| [OpenAI Codex](https://github.com/openai/codex) | Current fetched [guide](https://github.com/openai/codex/blob/main/docs/contributing.md) says no external code contributions or PRs. The search-engine copy still mentioned invitation-only contributions; the pinned GitHub snapshot is newer and controls this report. |
| [xAI Grok Build](https://github.com/xai-org/grok-build) | [CONTRIBUTING](https://github.com/xai-org/grok-build/blob/main/CONTRIBUTING.md) refuses external PRs/unsolicited changes. |
| [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) | [CONTRIBUTING](https://github.com/deepseek-ai/deepseek-harness/blob/main/CONTRIBUTING.md) says external PRs are not currently accepted. |
| [Google Gen AI Python SDK](https://github.com/googleapis/python-genai) | Its [guide](https://github.com/googleapis/python-genai/blob/main/CONTRIBUTING.md) says contributions will be accepted in the future. Do not treat it as open intake now. |
| [Mistral Vibe](https://github.com/mistralai/mistral-vibe) | [Code contribution section](https://github.com/mistralai/mistral-vibe/blob/main/CONTRIBUTING.md#code-contributions) still says code contributions are not accepted. Recent apparent outsider merges do not override the written policy; ask if it has changed. |
| [Continue core](https://github.com/continuedev/continue) | [README](https://github.com/continuedev/continue/blob/main/README.md) says no longer actively maintained/read-only. |
| [torchtune](https://github.com/meta-pytorch/torchtune), [Mistral Inference](https://github.com/mistralai/mistral-inference), [Cohere Toolkit](https://github.com/cohere-ai/cohere-toolkit), [Nous Atropos](https://github.com/NousResearch/atropos), [OpenHands CLI](https://github.com/OpenHands/OpenHands-CLI) | Archived or explicitly no longer maintained in the captured metadata/README. Prefer active successor surfaces; do not assume old CONTRIBUTING text is still an invitation. |
| [Claude Code](https://github.com/anthropics/claude-code), [Claude Agent SDK TypeScript](https://github.com/anthropics/claude-agent-sdk-typescript), [Cursor tracker](https://github.com/cursor/cursor) | Public tracker/distribution repositories are not proof that the underlying product implementation is available for external code work. Inspect the specific editable surface; use Python SDK/plugin repos for a more concrete route. No blanket external-code ban is inferred merely from the missing implementation. |
| [OpenAI Python generated resources](https://github.com/openai/openai-python), [Anthropic Python generated SDK surface](https://github.com/anthropics/anthropic-sdk-python), [Cohere Python](https://github.com/cohere-ai/cohere-python), [Mistral Python](https://github.com/mistralai/client-python) | Generation is a route constraint, not a universal ban. The OpenAI PR template warns generated changes may not merge; Cohere says direct generated additions cannot merge as-is; Mistral uses Speakeasy workflows. Ask for the source-of-truth route. |
| [Google ADK Python](https://github.com/google/adk-python) | It accepts contributions, but [Copybara landing](https://github.com/google/adk-python/blob/main/CONTRIBUTING.md#how-an-accepted-pull-request-lands) can close PRs and port them into credited commits. Avoid only if your metric insists on GitHub's green “Merged” state; otherwise track landed commits. |
| [Cline Kanban feature PRs](https://github.com/cline/kanban/blob/main/CONTRIBUTING.md), [Hermes new core memory providers](https://github.com/NousResearch/hermes-agent/blob/main/CONTRIBUTING.md) | Scope-specific refusal: bug/compatibility or standalone-plugin work may still be welcome. Do not generalize these restrictions to all contributions. |

This identifies explicit refusals found in the inspected repositories, not an exhaustive claim about every repository these organizations own. Public-source availability and permissive licensing do not imply willingness to review unsolicited patches.

## Measurement method and evidence limits

- **Repository inventory:** 32 lab/project groups, three screened surfaces each, plus explicit avoidance checks. GitHub repository metadata supplies canonical owner, stars, primary language, archived state and branch SHA. Ownership categories matter: Microsoft/NVIDIA ecosystems are broader than their research labs; MCP, PyTorch, vLLM, SGLang and SWE-agent are community/foundation/research-adjacent projects, not subsidiaries of OpenAI or Anthropic. Goose currently redirects to `aaif-goose/goose`.
- **Merged cohort:** start with the most recently updated 100 merged PRs; find the earliest merge date in that seed; query all merged PRs since that date, paginate, sort by actual `mergedAt`, then retain the newest 100. Repositories with fewer than 100 merges use all available merges. The downloadable metrics record whether the search exhausted; incomplete samples must not be described as exact last-100 samples. Cohort date windows are shown because a tiny dormant repository's “last 100” can cover years.
- **Bots:** exclude GraphQL Bot authors, deleted/unknown authors from outsider classification, and identifiable automation accounts such as dependabot, copybara/copyberry, Stainless/Fern bots and PEFT's jambot. Human-controlled bot accounts that do not advertise their purpose can remain; this is a limitation.
- **External estimate E/H:** E is human merged PRs with no detected owning-org/core-project affiliation; H is all non-bot authors in the sample, including unresolved author identities. Exclude MEMBER/OWNER, public owning-org membership, current company/job evidence and officially listed MCP maintainers. COLLABORATOR authors without resolved employment and former Continue founding-engineer history are conservatively excluded from E; Anthropic/OpenAI account suffixes are explicitly marked inferred. The report records every profile-based correction. A public profile cannot establish non-employment, so E/H is an **affiliation-adjusted proxy**, not a verified employment census or confidence interval.
- **MCP correction:** use the [official maintainer list](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/MAINTAINERS.md). A contributor label is especially misleading here. For example, the corrected recent Python SDK sample has only 4 candidate-outsider PRs among 98 human PRs, rather than treating the many core-maintainer PRs as external.
- **Denominators:** tables show E/H and the percentage after bot exclusion. They also give sample N and bot count, so E/N can be reconstructed. This is **share of merged work, not probability an external submission merges**. An acceptance-rate study would need a separate cohort of all external submissions, closed-unmerged outcomes, pending censoring and source-import attribution; that was not substituted with E/H.
- **Latency:** median calendar days from createdAt to mergedAt for the E subset only. This is survivor-biased and excludes pending/closed work. Tiny values may reflect pre-agreed/imported changes and are not an SLA.
- **Backlog:** open PR total includes bots and internal authors. Oldest external ages use the same affiliation heuristic on the 100 oldest open PRs. Finding a candidate there identifies the oldest candidate under that classifier; if none exists and more pages remain, the oldest external is unverified, not zero.
- **Policies:** fetch CONTRIBUTING files, PR templates, CODEOWNERS and all `.github/workflows/*.yml/.yaml` found in a recursive tree at a pinned SHA. Read relevant README status/generation notes. Per-repo evidence links identify inspected files. “Not specified/found” means no requirement found in this inspected repository-local material; organization defaults, external CLA apps, private required checks and off-GitHub CI may still apply. CI source was inspected; upstream CI suites were not executed.
- **Issue availability:** candidate discovery inspected up to 40–60 recently updated open issues per repo, expanded to as many as 400 in selected portfolio repositories. Thus “none verified” is a research gap, not proof that no suitable issue exists. Selected issues were individually re-fetched with fully paginated cross-reference/connection timelines; portfolio issues also received PR-body competition searches. The last 100 comments were fetched for each selected issue; counts above that would be flagged. Issue claims were not independently reproduced by running code.
- **Unverified areas:** hidden/historical employment; maintainer willingness and response probability; legal agreement status on your account; exact reason for unexplained closures; unlinked competing branches; hardware/cloud prerequisites not exercised; private organization intake rules. No stars-to-hiring conversion or personal hiring probability is claimed.

### Reproduce or refresh

The source scripts and JSON evidence are included in the downloadable evidence bundle. They call authenticated `gh api` and save public response data, not credentials. The snapshot is collected over an interval rather than a single transaction; each record carries its own collection time.

```bash
# Authored external public PR inventory (GET matters when passing fields)
gh api --method GET search/issues \
  -f 'q=is:pr author:rohan-patnaik -user:rohan-patnaik is:public' \
  -f per_page=100

# Check the exact current PR state and discussion
gh pr view 6070 --repo grafana/k6 \
  --json state,mergedAt,author,url,title,comments,reviews
# Check the portfolio issue:
gh issue view 4670 --repo OpenHands/software-agent-sdk \
  --json state,assignees,labels,body,comments,url

# Inspect all timeline pages; then inspect current open PRs for issue references
gh api --paginate repos/OpenHands/software-agent-sdk/issues/4670/timeline
# A numeric search can match dependency versions. Read the actual matches.
gh search prs '4670' --repo OpenHands/software-agent-sdk --limit 100

# Repository workflow/policy tree at a chosen commit
gh api 'repos/OWNER/REPO/git/trees/COMMIT_SHA?recursive=1'
```

Scripts in the evidence bundle provide the complete executable collection logic; the short commands above illustrate the checks.
