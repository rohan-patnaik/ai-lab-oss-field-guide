from collect import *
def exact(slug):
 f=ROOT/'raw'/(slug.replace('/','__')+'.json')
 if not f.exists():return slug,'missing'
 d=json.loads(f.read_text())
 if 'exactMerged' in d:return slug,'cached'
 old=d['merged']['nodes']
 if len(old)<100:d['exactMerged']=old;d['exactMergedComplete']=True
 else:
  since=sorted(p['mergedAt'] for p in old)[0][:10];qtext=f'repo:{d["nameWithOwner"]} is:pr is:merged merged:>={since}';nodes=[];cursor=None
  for page in range(15):
   q='query{search(type:ISSUE,query:'+json.dumps(qtext)+',first:100'+(',after:'+json.dumps(cursor) if cursor else '')+'){issueCount pageInfo{endCursor hasNextPage} nodes{... on PullRequest{'+PR+'}}}}'
   r=gql(q)['search'];nodes+=r['nodes'];cursor=r['pageInfo']['endCursor']
   if not r['pageInfo']['hasNextPage']:break
  d['exactMerged']=sorted(nodes,key=lambda p:p['mergedAt'],reverse=True)[:100];d['exactMergedComplete']=not r['pageInfo']['hasNextPage'];d['mergedSearch']={'query':qtext,'count':r['issueCount'],'fetched':len(nodes)}
 f.write_text(json.dumps(d,indent=2));return slug,len(d['exactMerged']),d['exactMergedComplete']
if __name__=='__main__':
 targets=list(dict.fromkeys(sum(CAT.values(),[])+AVOID))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  for r in ex.map(exact,targets):print(*r,flush=True)
