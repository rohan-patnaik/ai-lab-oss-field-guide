![](./banner.png)

# Cohere Developer Experience

At Cohere we aim to maximize developer productivity by meeting developers at their existing workflows: whether you want to use our model on our platform or on an external cloud platform, our aim is to provide the best experience available.

This repository is a one-stop-shop for Cohere developer experience. Here you can find docs, snippets, api specs and more to help you develop on the Cohere platform, or on AWS, Azure, OCI, or cohere-toolkit.

## How to use this repository

This repository is organized into the following sections:

- `fern/` contains content and configuration for https://docs.cohere.com
- `cohere-openapi.yaml` contains the OpenAPI spec for the Cohere platform API
- `snippets/` contains code snippets for using Cohere in various environments

## Other developer resources

### SDKs

We support the following SDKs which can be used to interact with the Cohere platform and cloud providers:

- [Python](https://github.com/cohere-ai/cohere-python)
- [Typescript](https://github.com/cohere-ai/cohere-typescript)
- [Java](https://github.com/cohere-ai/cohere-java)
- [golang](https://github.com/cohere-ai/cohere-go)


## How to contribute to this repository

We welcome contributions to this repository! Feel free to pull request any of the content you see and we will work with you to merge it. The OpenAPI sepcs and snippets are one-way synced from our internal repositories so we will need to take your changes and merge them behind the scenes.

## Making local builds

### About local builds

We encourage our contributors to build the site locally to validate rendering and links.

### Prerequisites

- [NPM](https://docs.npmjs.com/downloading-and-installing-node-js-and-npm)

### Installing the local build components

To install the components necessary to make local builds, run the following command from
the root of the repo.

```bash
make install
```

### Making a local build

To make a local build of the site, run the following command from the root of the repo.

```bash
make dev
```

## Python code changes

If you change any Python code samples, you must complete the following steps.

1. Install the required version of the [black](https://pypi.org/project/black/) package. Note that
   on MacOS, it's best to do so in a virtual environment to avoid interfering with Python packages
   used by the operating system.
   
   - MacOS
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install "black==24.10.0"
   ```

   - Non-MacOS
   ```bash
   pip3 install "black==24.10.0"
   ```

1. Automatically format your Python code using the following command from the root of the repo.

   ```bash
   python3 .github/scripts/check_python_code_snippets.py fern/pages
   ```
