![Checks](https://blog.continue.dev/_next/image?url=https%3A%2F%2Fha51p4k2fb4na0qd.public.blob.vercel-storage.com%2Fblog%2Fstandards-as-code-vercel-react-rules%2Fhero.jpeg&w=3840&q=75)

# Checks

A check is a markdown file describing a single code quality standard. Each check runs as a full AI agent on pull requests: reading files, running commands, and exercising judgment to catch issues that linters and tests can't express.

```markdown
---
name: Migration Safety
description: Flag destructive database migrations
---

If no migration files were added or changed, no action is needed.

When migrations are present, look for these issues:

- `DROP TABLE` or `DROP COLUMN` without a preceding data migration — add a backup step
- `NOT NULL` constraint added without a `DEFAULT` value — add a default or backfill
- A destructive and constructive change in the same migration — split for safe rollback
```

## Checks vs. tests vs. linting

**Linting** catches formatting and static patterns. If it can be a regex, it's a lint rule.

**Tests** verify behavior. If you can assert an input/output, write a test.

**Checks** handle judgment calls that require context, reading multiple files, understanding intent, applying conventions that aren't codified in a linter rule.

## Quick start

Install the skill:

```
npx skills add continuedev/checks
```

Then run the following skill in your preferred coding agent:

```
/setup-checks
```

The agent will analyze your project, create tailored check files in `.checks/`, and optionally set up CI.

## Example checks

Ready-to-use check files you can copy into your project:

| Check                                                           | Description                                                              |
| --------------------------------------------------------------- | ------------------------------------------------------------------------ |
| [Security Review](./.checks/security-review.md)                 | Catch hardcoded secrets, injection vectors, and missing input validation |
| [Test Coverage](./.checks/test-coverage.md)                     | Ensure new code has corresponding tests                                  |
| [Documentation Freshness](./.checks/documentation-freshness.md) | Keep docs in sync when public APIs or configuration changes              |
| [Dependency Audit](./.checks/dependency-audit.md)               | Review new or updated dependencies for risk                              |
| [Migration Safety](./.checks/migration-safety.md)               | Catch destructive database migrations                                    |

These are generic starting points. For best results, use the quickstart above to have your coding agent generate checks tailored to your project's specific frameworks, conventions, and pain points.

## Run locally

Just ask your coding agent to run the checks against your current diff.

Add this to your `AGENTS.md` (or `CLAUDE.md`, `COPILOT.md`) so your checks run automatically:

```markdown
Before opening a pull request, run all checks in `.checks/` against the current diff and fix any failures.
```

## Run in CI

The included [GitHub Actions workflow](./.github/workflows/checks.yml) uses Claude Code to run every check on each PR as a full AI agent. Results appear as individual GitHub status checks — passing checks complete silently, and failing checks post committable suggestion comments directly on the PR. Add `ANTHROPIC_API_KEY` as a repository secret in GitHub Settings > Secrets and variables > Actions.

See the [workflow YAML](./.github/workflows/checks.yml) for the full implementation.

## Learn more

[spec.md](./spec.md) — Full spec: check file format, best practices, CI workflow, design principles, and problems you'll run into.

## License

[Apache 2.0](./LICENSE)
