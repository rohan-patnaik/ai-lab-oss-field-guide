from collect import *
slugs=['openai/openai-cookbook','modelcontextprotocol/go-sdk','huggingface/peft','EleutherAI/lm-evaluation-harness','OpenHands/software-agent-sdk','NVIDIA/garak','SWE-agent/mini-swe-agent','mistralai/mistral-common','PrimeIntellect-ai/prime','vllm-project/production-stack']
def more(slug):
 f=ROOT/'raw'/(slug.replace('/','__')+'.json');d=json.loads(f.read_text());own,name=slug.split('/');cursor=None;allnodes=[]
 for i in range(4):
  q='query{repository(owner:'+json.dumps(own)+',name:'+json.dumps(name)+'){issues(first:100,states:OPEN,orderBy:{field:CREATED_AT,direction:DESC}'+(',after:'+json.dumps(cursor) if cursor else '')+'){pageInfo{hasNextPage endCursor} nodes{'+ISS.replace('last:30','last:10')+'}}}}'
  r=gql(q)['repository']['issues'];allnodes+=r['nodes'];cursor=r['pageInfo']['endCursor']
  if not r['pageInfo']['hasNextPage']:break
 d['expandedIssues']={'nodes':allnodes,'hasNextPage':r['pageInfo']['hasNextPage']};f.write_text(json.dumps(d,indent=2));return slug,len(allnodes)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 for x in ex.map(more,slugs):print(*x,flush=True)
