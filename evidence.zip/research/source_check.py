from collect import *
checks={
'google-deepmind/mujoco':['src/user/user_model.cc','src/user/user_api.cc'],
'OpenHands/software-agent-sdk':['openhands-sdk/openhands/sdk/conversation/impl/remote_conversation.py','openhands-agent-server/openhands/agent_server/api.py'],
'SWE-agent/SWE-ReX':['README.md','pyproject.toml'],
'EleutherAI/lm-evaluation-harness':['scripts/write_out.py','lm_eval/__main__.py'],
'vllm-project/production-stack':['vllm_router/entrypoints/openai/api_server.py','vllm_router/entrypoints/openai/route_request.py']}
for s,paths in checks.items():
 o,n=s.split('/');fields=' '.join('f'+str(i)+':object(expression:'+json.dumps('HEAD:'+p)+'){...on Blob{text oid}}' for i,p in enumerate(paths));r=gql('query{repository(owner:'+json.dumps(o)+',name:'+json.dumps(n)+'){'+fields+'}}')['repository'];out={p:r['f'+str(i)] for i,p in enumerate(paths)};(ROOT/'raw'/(s.replace('/','__')+'__source-check.json')).write_text(json.dumps(out,indent=2));print(s,[(p,bool(b)) for p,b in out.items()])
