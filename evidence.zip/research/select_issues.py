from candidates import *
from analyze import analyze
SKIP=re.compile(r'\b(test issue|tool test|integration test issue|smoke|my issue|verify evals|papers with code|consciousness|energy reduction|Rastakh|Restaakh|how (to|can)|question|help me|does .*support|EvalPort|proposal.*(?:integration|skill)|[\U0001f000-\U0001ffff])',re.I)
def bucket(a):
 t=a['title'];l=' '.join(x['name'] for x in a['labels']['nodes'])
 if re.search(r'\b(doc|docs|document|documentation|typo|readme|usage examples|add.*test|test coverage|test `|test for|flakey|flaky)\b',t,re.I) or l=='documentation':return 'LOW'
 if re.search(r'feature|proposal|support|add |implement|perf|optimi|throughput|benchmark|memory|parallel|recompile|typed APIs|capabilit',t,re.I) or 'enhancement' in l:return 'HIGH'
 return 'MEDIUM'
manual={
'SWE-agent/SWE-ReX':{'LOW':[92,75],'MEDIUM':[241],'HIGH':[111]},
'EleutherAI/lm-evaluation-harness':{'LOW':[2356,2639],'MEDIUM':[3276],'HIGH':[2964]},
'OpenHands/software-agent-sdk':{'LOW':[5048],'MEDIUM':[4670,4731],'HIGH':[4978,4973]},
'google-deepmind/mujoco':{'LOW':[],'MEDIUM':[],'HIGH':[3596,3585]},
'vllm-project/production-stack':{'LOW':[],'MEDIUM':[628,785],'HIGH':[1034]},
'openai/openai-cookbook':{},'huggingface/peft':{},'anthropics/skills':{},'cursor/cookbook':{},
'openai/openai-agents-python':{'HIGH':[5088]},'openai/openai-agents-js':{},
'modelcontextprotocol/go-sdk':{'HIGH':[1263]},
'PrimeIntellect-ai/prime-rl':{'HIGH':[2568]},
}
result={}
for slug in sum(CAT.values(),[]):
 f=ROOT/'raw'/(slug.replace('/','__')+'.json')
 if not f.exists():result[slug]={};continue
 d=json.loads(f.read_text());nodes=d.get('expandedIssues',d['issues'])['nodes'];chosen={}
 if slug in manual:
  for b,nums in manual[slug].items():chosen[b]=[next(a for a in nodes if a['number']==n) for n in nums if any(a['number']==n for a in nodes)]
 else:
  for a in candidates(slug):
   if SKIP.search(a['title']) or len(a['body'])<60 or len(a['title'])<14:continue
   labels=' '.join(l['name'] for l in a['labels']['nodes'])
   if re.search(r'internal.only|maintainer.only',labels,re.I):continue
   b=bucket(a)
   if b not in chosen:chosen[b]=[a]
 result[slug]=chosen
(ROOT/'shortlist.json').write_text(json.dumps(result,indent=2))
for s,bs in result.items():
 if bs:
  print('\n'+s)
  for b,items in bs.items():
   for a in items:print(b,a['number'],a['title'][:125])
