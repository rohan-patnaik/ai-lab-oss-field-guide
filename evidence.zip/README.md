# AI Lab OSS Field Guide

Research snapshot for Rohan Patnaik, collected on 18 September 2026.

- `report.md`: full Markdown report, written before the HTML page.
- `public/report.html`: standalone page; CSS, JavaScript and report content are inline.
- `public/metrics.json`: measured repository statistics and affiliation corrections.
- `public/issues.json`: individually checked issue candidates.
- `public/evidence.zip`: public API responses, pinned policy snapshots and collection scripts.
- `research/narrative.md` and `research/annotations.py`: editorial analysis.

## Run the site

```bash
npm ci
npm run dev
npm run build
```

The root route serves the same HTML as the standalone download. No API key or GitHub access is required to read the report. Only the local theme preference uses browser storage.

## Rebuild the report

The research collectors require Python 3 and authenticated GitHub CLI access. Unzip the evidence bundle at the project root to restore the ignored API/policy snapshots. Review `research/collect.py` before refreshing: a full audit makes many GitHub API calls.

To render from the saved evidence:

```bash
python3 -m pip install --target /tmp/oss-report-python markdown==3.8.2
python3 research/build_report.py
python3 research/build_html.py
npm run build
```

The public evidence contains no authentication tokens. Raw history is public upstream data; affiliation classifications are explicitly approximate. Issue availability must be checked again before work starts.
